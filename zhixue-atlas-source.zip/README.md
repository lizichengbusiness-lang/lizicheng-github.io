# 知学图谱

面向零基础学习的通用书籍与科目工作台。可以从书名、科目名称、学习大纲或教材的封面与目录开始，逐步建立学习课程与思维导图。保留《动物生物化学》（马海田，第六版）作为最初的示例项目。

## 已有功能

- 多学习空间：一本书或一个科目拥有独立的主题、讲解、思维导图、可供选择的课程、笔记、收藏和学习进度。可从“我的书架”切换，新增项目不覆盖原有项目。
- 原动物生物化学项目包含24节可直接阅读的入门示例课：学习目标、情境引入、术语解释、逐步教学、带推理的实例、可展开答案的理解检查。讲解是学科入门示例，不是第六版原文摘录。
- 新增“高等数学”“Python 入门”“历史学习方法”3个通用示例，每个示例有8个主题，前2课提供完整入门讲解，其余主题可以逐节编写。它们用于体验学习方式，不冒充某一本教材的对应目录。
- 自定义科目可填写学习基础、选择学科领域，或直接粘贴已有大纲。没有配置模型时仍可建立空白学习项目或按目录建课；自动编写新框架和详细讲解需要配置自己的模型API。
- 思维导图按全书、章节、知识点逐层聚焦。点击章节只显示本章知识点；点击知识点只显示所属章节、直接前置与后续知识及本节概念，无关分支隐藏。支持层级导航、返回、拖动、缩放、适应画布与搜索跳转。
- 原“网课资料库”统一更名为“可供选择的课程”，继续保留原站链接。
- 动物生物化学示例保留4个课程入口：B站南京农业大学、B站华南农业大学96讲、YouTube MIT 5.07SC、YouTube MIT 7.05代谢选讲。新项目从空课程列表开始，按当前科目搜索或手动收录，不混入其他项目的课程。
- 网课仅保存来源信息和原站URL，点击前往YouTube或B站学习，不对视频进行再加工。
- 课程筛选、手动收录、原站搜索。B站联网检索受平台可用性影响；YouTube联网检索需要用户的YouTube Data API密钥。
- 笔记、收藏、掌握标记与学习资料保存在当前浏览器。导出JSON备份包含完整书架的所有学习空间，不包含API密钥、模型设置或图片草稿。导入完整学习库或旧版单书备份时保留已有空间；ID冲突会创建副本，不覆盖原项目。
- 封面加目录即可建课，无需整本教材正文。支持1张封面及最多5张目录图，识别书名、作者、版次和目录后人工校对，再创建学习单元；也可直接粘贴目录，无需图片模型。
- 新目录逐节生成完整入门讲解；后端尝试读取公开参考资料，成功与失败均标注。资料链接只来自实际读取结果，不采信模型自造的来源。
- 新科目/书名可生成“未核对教材”的初步框架；已选知识点可继续提问。讲解与公开资料会参考当前学科和学习基础；未知领域在没有可读取参考资料时明确标注，不添加无关的生物化学来源。

## 开始使用

从“我的书架”选择示例，或新建自己的书籍与科目。已有目录时可以直接粘贴大纲，也可以上传一张封面和多张目录图，识别后校对书名、作者、版本与章节，再确认建立课程。只需封面和目录，无需上传整本教材。

在思维导图中点击章节或知识点，逐层聚焦相关内容；进入知识点后阅读现有讲解，或按需编写本节的入门课。课程检索、收藏与笔记都属于当前学习空间，切换项目后仍然保留。

## 记录迁移与备份

首次打开新版时优先读取浏览器的 `zhixue-library-v3` 学习库。如果没有新版记录，会自动将旧的 `zhixue-atlas-v1` 单书记录迁移为一个学习空间，保留原有知识点、已生成讲解、已收藏课程、笔记与进度；旧记录不会被删除。

学习记录不会自动跨浏览器或跨设备同步。换浏览器、清理本地数据或迁移设备前，请导出完整学习库备份；在目标浏览器导入即可合并到书架。存储空间不足或存储不可用时会提示，页面中的当前会话资料仍保留，可立即导出备份。模型密钥需在新会话重新配置。

从原来的 `chatgpt.site` 网站切换到 GitHub Pages 时，域名发生变化，浏览器不会自动迁移本地记录。请先在旧站导出完整学习库，在新站的“书架与科目”中导入。上面的旧版本自动迁移仅适用于同一网站来源中的浏览器记录。

## GitHub Pages 构建与部署

项目包含独立的 Vite React 静态入口，复用现有学习界面，不依赖 Sites 登录。推荐使用 Node.js 24 安装和检查项目：

```powershell
npm ci
npm run build:pages
npm run preview:pages
```

静态产物为 `dist-pages/`，构建配置为 `vite.pages.config.ts`，入口为 `github/pages/`。GitHub Actions 中会根据 `GITHUB_REPOSITORY` 自动选择仓库子路径；个人主页仓库采用 `/`，项目仓库采用 `/仓库名/`。独立域名等场景可在构建时通过 `STUDY_BASE_PATH` 显式覆盖，例如 `/`。

当前仓库采用压缩源码交付方式：仓库根目录的 `zhixue-atlas-source.zip` 保存完整可编辑源码，`.github/workflows/pages.yml` 将其解压到 `site-source/`，执行依赖安装与 `build:pages`，再发布 `site-source/dist-pages/`。首次使用时在仓库 `Settings → Pages` 中选择 `GitHub Actions` 作为发布来源。后续替换同名源码ZIP并提交，工作流会重新构建；也可以在Actions中手动运行发布。

编辑代码时，下载并解压 `zhixue-atlas-source.zip`，在解压后的源码根目录运行项目。修改完成后重新打包源码、替换仓库中的同名ZIP即可。ZIP顶层应直接包含 `package.json`、锁文件、`app/`、`components/`、`lib/`、`github/` 等，不要额外包一层目录，也不要将 `node_modules/`、构建产物或学习备份打包进去。详细操作见 [GitHub部署说明](github/DEPLOY.md)。

### 独立后端

GitHub Pages只承载静态网页。示例课、思维导图、粘贴目录建课、书架、笔记、备份和课程外链可直接使用；图片识别、AI生成讲解、答疑及站内联网找课需要另行部署后端。

源码提供 `github/api-worker.ts` 与 `github/wrangler.api.jsonc`，可部署为Cloudflare Worker，复用原来的 `/api/model` 和 `/api/courses` 接口。在配置的 `ALLOWED_ORIGINS` 中填入允许的网站来源，例如 `https://lizichengbusiness-lang.github.io`；这里不包含仓库路径、末尾斜杠或通配符。默认留空时不会允许网站调用模型与课程接口。

完成后端部署后，在网页“模型与搜索设置”填写该服务的HTTPS源地址，例如 `https://你的服务.workers.dev`，再填自己的模型与YouTube API密钥。服务地址不附加 `/api` 或仓库路径。后端地址和密钥仅在当前会话使用，不进入学习库备份或静态构建。请求内容及相应密钥会发送到所填后端，因此应填写自己部署或信任的服务。

此Pages工作流不会同时部署后端，也不会把原来的私有Sites网站直接用作跨域接口。未配置后端时，网页会说明所需设置，已有学习内容与原站搜索入口仍可使用。

## 运行

需要Node.js 22.13以上。

```powershell
npm ci
npm run dev
```

若Windows的npm启动路径异常，可直接运行同一Node入口：

```powershell
node scripts/run-framework.mjs dev
```

本地默认地址：http://127.0.0.1:5173/

```powershell
node node_modules/typescript/bin/tsc --noEmit
node --import ./tests/typescript-loader.mjs tests/learning.test.mjs
node --import ./tests/typescript-loader.mjs tests/links.test.mjs
node --import ./tests/typescript-loader.mjs tests/mindmap.test.mjs
node --import ./tests/typescript-loader.mjs tests/library.test.mjs
node --import ./tests/typescript-loader.mjs tests/subjects.test.mjs
node --import ./tests/typescript-loader.mjs tests/contents.test.mjs
node --import ./tests/typescript-loader.mjs tests/contents-update.test.mjs
node scripts/run-framework.mjs build
```

## 模型与资料

在程序“模型与搜索设置”中配置自己的API，文字讲解支持DeepSeek、通义千问和OpenAI官方聊天接口。图片识别单独配置支持图片输入的通义千问或OpenAI模型及对应密钥。模型ID以自己账号实际可用名称为准。密钥只留在当前页面会话，不写入学习存储或备份。点击识别、编写或提问后，相关图片或文本经本站后端转发给所选服务商，可能产生费用。测试脚本使用Node.js 24的TypeScript加载能力。

未配置密钥时，动物生物化学的24节入门示例课、3个新示例的前2课、思维导图、笔记与已有课程入口照常可用，粘贴目录也可建立章节结构。图片仅暂存当前页面；书目信息、确认目录与已生成讲解存于各自学习空间，可随完整书架导出JSON备份。

动物生物化学第六版的实际目录尚未收到。封面和目录可以确定学习结构，但不足以保证包含正文所有细节。对任何书籍，讲解均围绕学科知识另行编写，不冒充教材原文，不编造页码。通用示例、AI初步框架、实际确认目录及参考网课都有各自的来源标记。

## 验证与参考

测试涵盖目录层级解析、示例课程结构完整性、讲解备份往返、课程URL与图谱引用、旧记录迁移、多空间切换隔离、异步结果按项目ID保存、导入冲突处理、密钥和草稿剔除。接口测试模拟图片与讲解模型响应，检查多模态消息、学科上下文、来源传递及无效请求拒绝。真实图片识别准确率、真实模型讲解效果及YouTube带密钥自动搜索尚未验证；当前没有可用模型密钥或用户教材图片。

开源参考：

- https://github.com/googleapis/google-api-nodejs-client ：官方API调用模式；当前实现使用同一YouTube REST接口。
- https://github.com/LuanRT/YouTube.js ：非官方搜索/播放列表客户端，未集成。
- https://github.com/HKUDS/DeepTutor ：学习工作台和知识库组织思路，未复制源码。

`.openai/hosting.json`保存当前Site身份，继续发布该Site时保留它。作为独立新项目部署时，按目标平台的流程另行配置。

## 视觉与背景

交互使用午夜蓝、青绿和少量古金色，提供悬停、按下、选中和键盘焦点状态。思维导图章节为粗框与加厚左边，知识点为细线圆角框，概念为虚线框；聚焦时仍保留类别区别。页头与课程卡片根据学科切换主题插画：生命科学沿用两张ImageGen生物化学配图，其他领域使用坐标函数、代码逻辑或书籍与史料主题图。配图是学习氛围装饰，不是教材中的精确图示或课程截图。图片随源码保存在public/images/，其他学科图形在components/SubjectArtwork.tsx中维护。

右上角“学科背景”可关闭页面和图谱的装饰背景，选择独立保存在当前浏览器，刷新后保留，不影响配图或学习资料。背景样式集中在app/visual-theme.css，交互配色集中在app/interaction-theme.css，便于继续调整或撤销。
