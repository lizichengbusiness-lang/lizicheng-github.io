'use client';
import {useEffect,useId,useMemo,useRef,useState,type PointerEvent} from 'react';
import {ArrowLeft,BookOpen,Check,ChevronRight,Focus,Home,Layers,Maximize,Minus,Plus,Search,X} from 'lucide-react';
import type {Topic} from '@/lib/learning-data';
import {edgeCurve,makeMindmap,mapBounds,sameFocus,type MapFocus,type MapNode} from '@/lib/mindmap-layout';

type Camera={x:number;y:number;k:number};
const BOOK:MapFocus={kind:'book'};
const COLORS=['#58748f','#a67c3d','#157b78','#7b678f'];
export default function KnowledgeAtlas({topics,selected,onSelect,onRead,learned,bookTitle,fromContents}:{topics:Topic[];selected:string;onSelect:(id:string)=>void;onRead:(id:string)=>void;learned:string[];bookTitle:string;fromContents:boolean}){
 const [focus,setFocus]=useState<MapFocus>(BOOK),[history,setHistory]=useState<MapFocus[]>([]),[query,setQuery]=useState(''),[concept,setConcept]=useState<MapNode|null>(null);
 const [size,setSize]=useState({width:1000,height:620}),[camera,setCamera]=useState<Camera>({x:0,y:0,k:1}),[panning,setPanning]=useState(false);
 const viewport=useRef<HTMLDivElement>(null),gesture=useRef<{x:number;y:number;camera:Camera}|null>(null);
 const marker=useId().replace(/:/g,''),groups=useMemo(()=>[...new Set(topics.map(t=>t.group))],[topics]);
 const layout=useMemo(()=>makeMindmap(topics,focus,bookTitle,fromContents),[topics,focus,bookTitle,fromContents]);
 const byId=new Map(layout.nodes.map(n=>[n.id,n])),current=focus.kind==='topic'?topics.find(t=>t.id===focus.id):undefined;
 const chapter=focus.kind==='chapter'?focus.id:current?.group;
 const matches=query.trim()?[
  ...groups.filter(g=>g.toLowerCase().includes(query.toLowerCase())).map(g=>({title:g,subtitle:fromContents?'章节':'学习模块',target:{kind:'chapter',id:g} as MapFocus})),
  ...topics.filter(t=>t.title.toLowerCase().includes(query.toLowerCase())).map(t=>({title:t.title,subtitle:t.group,target:{kind:'topic',id:t.id} as MapFocus})),
 ]:[];

 function fit(){const bounds=mapBounds(layout.nodes),k=Math.min(1.32,(size.width-28)/bounds.width,(size.height-34)/bounds.height);setCamera({k,x:(size.width-bounds.width*k)/2-bounds.x*k,y:(size.height-bounds.height*k)/2-bounds.y*k});}
 useEffect(()=>{const element=viewport.current;if(!element)return;const observer=new ResizeObserver(([entry])=>setSize({width:entry.contentRect.width,height:entry.contentRect.height}));observer.observe(element);return()=>observer.disconnect();},[]);
 useEffect(()=>{fit();},[layout,size.width,size.height]); // New focus always fits its own subgraph.
 useEffect(()=>{const element=viewport.current;if(!element)return;const handler=(event:WheelEvent)=>{if(!event.ctrlKey&&!event.metaKey)return;event.preventDefault();const rect=element.getBoundingClientRect(),px=event.clientX-rect.left,py=event.clientY-rect.top;setCamera(c=>{const k=Math.min(2.5,Math.max(.18,c.k*Math.exp(-event.deltaY*.004))),ratio=k/c.k;return{k,x:px-(px-c.x)*ratio,y:py-(py-c.y)*ratio};});};element.addEventListener('wheel',handler,{passive:false});return()=>element.removeEventListener('wheel',handler);},[]);
 function navigate(next:MapFocus){setQuery('');if(sameFocus(next,focus))return;setHistory(v=>[...v,focus]);setFocus(next);setConcept(null);if(next.kind==='topic')onSelect(next.id);}
 function overview(){setFocus(BOOK);setHistory([]);setQuery('');setConcept(null);}
 function back(){const last=history.at(-1);if(!last){overview();return;}setFocus(last);setHistory(v=>v.slice(0,-1));setConcept(null);setQuery('');if(last.kind==='topic')onSelect(last.id);}
 function zoom(factor:number){setCamera(c=>{const k=Math.min(2.5,Math.max(.18,c.k*factor)),ratio=k/c.k;return{k,x:size.width/2-(size.width/2-c.x)*ratio,y:size.height/2-(size.height/2-c.y)*ratio};});}
 function down(event:PointerEvent<HTMLDivElement>){if(event.button!==0||(event.target as Element).closest('button'))return;gesture.current={x:event.clientX,y:event.clientY,camera};event.currentTarget.setPointerCapture(event.pointerId);setPanning(true);}
 function move(event:PointerEvent<HTMLDivElement>){const start=gesture.current;if(start)setCamera({...start.camera,x:start.camera.x+event.clientX-start.x,y:start.camera.y+event.clientY-start.y});}
 function up(event:PointerEvent<HTMLDivElement>){gesture.current=null;setPanning(false);if(event.currentTarget.hasPointerCapture(event.pointerId))event.currentTarget.releasePointerCapture(event.pointerId);}
 function nodeClick(node:MapNode){if(node.kind==='concept'){setConcept(node);return;}if(node.target)navigate(node.target);}
 return <section className="mindmap" aria-label="交互式知识思维导图">
  <div className="mindmap-toolbar">
   <nav className="map-breadcrumb" aria-label="思维导图层级"><button onClick={overview} aria-label="返回全书导图"><Home size={15}/><span>全书</span></button>{chapter&&<><ChevronRight size={13}/><button onClick={()=>navigate({kind:'chapter',id:chapter})} aria-current={focus.kind==='chapter'?'page':undefined}>{chapter}</button></>}{current&&<><ChevronRight size={13}/><span aria-current="page">{current.title}</span></>}</nav>
   <div className="mindmap-search"><Search size={15}/><input aria-label="查找并聚焦章节或知识点" placeholder="查找章节或知识点" value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&matches[0]){e.preventDefault();navigate(matches[0].target);}if(e.key==='Escape')setQuery('');}}/>{query&&<button aria-label="清除图谱搜索" onClick={()=>setQuery('')}><X size={13}/></button>}
    {query.trim()&&<div className="map-search-results"><span>{matches.length?`找到 ${matches.length} 项，点击聚焦`:'没有匹配的章节或知识点'}</span>{matches.slice(0,10).map((m,i)=><button key={i} onClick={()=>navigate(m.target)}><strong>{m.title}</strong><small>{m.subtitle}</small><Focus size={15}/></button>)}{matches.length>10&&<small>请输入更完整的名称缩小范围。</small>}</div>}
   </div>
  </div>
  <div className="map-heading"><div><strong>{layout.focusTitle}</strong><p aria-live="polite">{layout.description}</p></div><div className="map-navigation">{focus.kind!=='book'&&<button className="quiet-button" onClick={back}><ArrowLeft size={15}/>返回上一级</button>}{focus.kind==='book'?<button className="quiet-button" disabled={!topics.some(t=>t.id===selected)} onClick={()=>navigate({kind:'topic',id:selected})}><Focus size={15}/>聚焦当前知识点</button>:<button className="quiet-button" onClick={overview}><Layers size={15}/>返回全图</button>}</div></div>
  <div className="map-legend"><span title="粗实线、加厚左边与近方角表示章节层级"><i className="map-legend-chapter"/>{fromContents?'章节':'模块'} · 粗框</span><span title="细实线胶囊边框表示具体知识点，聚焦时仍保留细边框"><i className="map-legend-topic"/>知识点 · 细框</span><span title="虚线胶囊边框表示本节术语，可点击查看释义"><i className="map-legend-concept"/>概念 · 虚线</span><span><i className="map-legend-edge"/>前置 → 后续</span><span><Check size={12}/>已理解</span></div>
  <div className={`mindmap-viewport ${panning?'is-panning':''}`} ref={viewport} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up} onKeyDown={e=>{if(e.key==='Escape'&&focus.kind!=='book')back();}}>
   <svg viewBox={`0 0 ${size.width} ${size.height}`} role="group" aria-label={`${layout.focusTitle}，可点击节点聚焦`}>
    <defs><marker id={`${marker}-arrow`} viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 1 1 L 9 5 L 1 9" fill="none" stroke="#58748f" strokeWidth="1.5"/></marker></defs>
    <g className={`mindmap-world ${panning?'dragging':''}`} style={{transform:`translate(${camera.x}px,${camera.y}px) scale(${camera.k})`}}>
     {layout.edges.map((edge,i)=>{const a=byId.get(edge.from),b=byId.get(edge.to);if(!a||!b)return null;const relation=edge.kind==='before'||edge.kind==='after';return <path key={`${focus.kind}-${i}`} className={`map-edge edge-${edge.kind}`} d={edgeCurve(a,b,edge.kind==='concept')} stroke={relation?'#58748f':COLORS[edge.tone]} markerEnd={relation?`url(#${marker}-arrow)`:undefined} fill="none"/>;})}
     {layout.nodes.map(node=><foreignObject x={node.x} y={node.y} width={node.width} height={node.height} key={node.id}>
      <button className={`mind-node mind-${node.kind} tone-${node.tone} ${node.central?'central':''} ${node.kind==='chapter'&&node.height<90?'compact':''} ${node.topicId&&learned.includes(node.topicId)?'understood':''}`} onClick={()=>nodeClick(node)} aria-label={`${node.kind==='concept'?'查看概念释义':node.central?'当前节点':'聚焦'}：${node.title}`} aria-current={node.central?'true':undefined} title={node.kind==='concept'?node.meaning:node.title}>
       <span className="mind-node-kind">{node.kind==='book'?<BookOpen size={15}/>:node.kind==='chapter'?<Layers size={14}/>:node.topicId&&learned.includes(node.topicId)?<Check size={14}/>:<span className="mind-node-dot"/>}<span>{node.kind==='book'?'学习全貌':node.kind==='chapter'?(fromContents?'目录章节':'学习模块'):node.subtitle}</span>{!node.central&&node.kind!=='concept'&&<Focus size={13}/>}</span>
       <strong>{node.title}</strong>{(node.kind==='chapter'||node.kind==='book')&&<small>{node.subtitle}{!node.central&&node.kind==='chapter'&&!node.subtitle.includes('点击')?' · 点击展开':''}</small>}
      </button>
     </foreignObject>)}
    </g>
   </svg>
   <div className="map-zoom" aria-label="思维导图缩放"><button aria-label="缩小导图" onClick={()=>zoom(1/1.2)}><Minus size={17}/></button><span aria-live="off">{Math.round(camera.k*100)}%</span><button aria-label="放大导图" onClick={()=>zoom(1.2)}><Plus size={17}/></button><i/><button aria-label="适应画布" onClick={fit}><Maximize size={16}/></button></div>
   <div className="map-canvas-hint">点击节点聚焦 · 拖动画布移动</div>
  </div>
  {concept&&<div className="map-concept-detail" role="status"><div><small>概念释义</small><strong>{concept.title}</strong><p>{concept.meaning}</p></div><button aria-label="关闭概念释义" onClick={()=>setConcept(null)}><X size={17}/></button></div>}
  <div className="map-footer"><span>{focus.kind==='book'?`${topics.length} 个知识点，点击章节逐层探索`:`当前显示 ${layout.nodes.filter(n=>n.kind==='topic').length} 个知识点 · 已隐藏无关分支`}</span>{current?<button className="primary-button" onClick={()=>onRead(current.id)}><BookOpen size={16}/>阅读这一课</button>:<span>支持 + / − 缩放、适应画布，Ctrl + 滚轮缩放</span>}</div>
 </section>;
}
