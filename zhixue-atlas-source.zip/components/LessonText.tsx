// Render model/code examples as text only; no HTML from lessons is executed.
export default function LessonText({text}:{text:string}){
 const parts=text.split(/(```[\s\S]*?```)/g);
 return <div className="lesson-prose">{parts.filter(Boolean).map((part,i)=>part.startsWith('```')?<pre key={i}><code>{part.replace(/^```[^\n]*\n?/,'').replace(/```$/,'').trim()}</code></pre>:<p key={i}>{part}</p>)}</div>;
}
