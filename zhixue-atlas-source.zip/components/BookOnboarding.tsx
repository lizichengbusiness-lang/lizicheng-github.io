'use client';
import {useEffect,useRef,useState} from 'react';
import {BookOpen,Check,ImagePlus,LoaderCircle,Settings2,Trash2} from 'lucide-react';
import {parseContents,topicsFromContents,type BookPlan} from '@/lib/curriculum';
import {parseJsonResponse,type ModelSettings} from '@/lib/learning-utils';
import type {Topic} from '@/lib/learning-data';
import {fieldOptions,inferField,type StudyField} from '@/lib/subject-catalog';
import {apiUrl} from '@/lib/runtime-urls';
type Photo={name:string;data:string;role:'cover'|'toc'};
export type BookDraft={photos:Photo[];title:string;author:string;edition:string;toc:string;field?:StudyField;level?:string};
async function photo(file:File):Promise<string>{
 if(!/^image\/(jpeg|png|webp)$/.test(file.type))throw new Error('请使用JPG、PNG或WebP图片。');
 if(file.size>15*1024*1024)throw new Error('每张原图请小于15MB。');
 const bitmap=await createImageBitmap(file),scale=Math.min(1,1800/Math.max(bitmap.width,bitmap.height));
 const canvas=document.createElement('canvas');canvas.width=Math.round(bitmap.width*scale);canvas.height=Math.round(bitmap.height*scale);
 canvas.getContext('2d')!.drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();
 const data=canvas.toDataURL('image/jpeg',.84);if(data.length>1500000)throw new Error('图片过大，请缩小尺寸后再试。');return data;
}
export default function BookOnboarding({settings,onApply,onSettings,onBackup,onBusy,draft,onDraft,actionLabel='我已校对，建立学习路线'}:{settings:ModelSettings;onApply:(plan:BookPlan,topics:Topic[])=>void;onSettings:()=>void;onBackup:()=>void;onBusy:(b:boolean)=>void;draft:BookDraft|null;onDraft:(d:BookDraft)=>void;actionLabel?:string}){
 const [photos,setPhotos]=useState<Photo[]>(draft?.photos||[]),[title,setTitle]=useState(draft?.title||''),[author,setAuthor]=useState(draft?.author||''),[edition,setEdition]=useState(draft?.edition||''),[toc,setToc]=useState(draft?.toc||''),[field,setField]=useState<StudyField|'auto'>(draft?.field||'auto'),[level,setLevel]=useState(draft?.level||'零基础'),[busy,setBusy]=useState(false),[error,setError]=useState(''),[recognized,setRecognized]=useState(false);
 useEffect(()=>onDraft({photos,title,author,edition,toc,field:field==='auto'?undefined:field,level}),[photos,title,author,edition,toc,field,level,onDraft]);
 const cover=useRef<HTMLInputElement>(null),contents=useRef<HTMLInputElement>(null),abort=useRef<AbortController|null>(null);
 useEffect(()=>()=>abort.current?.abort(),[]);
 const chapters=parseContents(toc),count=chapters.reduce((n,c)=>n+(c.sections.length||1),0);
 async function add(files:FileList|null,role:Photo['role']){if(!files)return;setError('');try{const incoming=Array.from(files);if(role==='toc'&&incoming.length+photos.filter(p=>p.role==='toc').length>5)throw new Error('目录最多5张。可先识别，再在目录文本中补充。');const kept=role==='cover'?photos.filter(p=>p.role!=='cover'):photos;if(kept.length+incoming.length>6)throw new Error('最多6张：1张封面和最多5张目录，可分次补充目录文字。');const result:Photo[]=[];for(const file of incoming)result.push({name:file.name,data:await photo(file),role});setPhotos([...kept,...result]);setRecognized(false);}catch(e){setError((e as Error).message);}}
 async function recognize(){
  if(!settings.visionKey||!settings.visionModel){setError('请先配置图片识别模型，或直接在下方输入书名、粘贴目录。无需教材正文。');return;}
  const controller=new AbortController();abort.current=controller;setBusy(true);onBusy(true);setError('');
  try{const response=await fetch(apiUrl('/api/model',settings.backendUrl),{method:'POST',headers:{'Content-Type':'application/json'},signal:controller.signal,body:JSON.stringify({task:'bookvision',text:'按上传顺序识别封面与目录。图片身份：'+photos.map((p,i)=>`${i+1}:${p.role==='cover'?'封面':'目录'} ${p.name}`).join('；'),images:photos.map(p=>p.data),provider:settings.visionProvider||'qwen',model:settings.visionModel,apiKey:settings.visionKey})});const data=await response.json() as {error?:string;text:string};if(!response.ok)throw new Error(data.error||'图片识别失败');const d=parseJsonResponse(data.text);if(typeof d.toc!=='string'||!d.toc.trim())throw new Error('未识别到目录文字，请检查图片或在下方手动补充。');if(typeof d.title==='string'&&d.title.trim())setTitle(d.title);if(typeof d.author==='string'&&d.author.trim())setAuthor(d.author);if(typeof d.edition==='string'&&d.edition.trim())setEdition(d.edition);setToc(d.toc);setRecognized(true);}
  catch(e){if(!controller.signal.aborted)setError((e as Error).message);}finally{setBusy(false);onBusy(false);abort.current=null;}
 }
 return <div className="book-onboarding"><div className="import-intro"><span>只需封面 + 目录</span><h3>把一本书变成你的学习路线</h3><p>拍摄封面和目录页即可。目录决定章节结构，讲解围绕各节主题另行编写。</p></div><div className="onboard-step"><b>1</b><div><h3>放入图片</h3><p>目录可以多张，按页码顺序选择。图片暂存当前窗口。</p></div></div>
 <input type="file" ref={cover} className="hidden-file" accept="image/jpeg,image/png,image/webp" onChange={e=>{add(e.target.files,'cover');e.target.value='';}}/>
 <input type="file" ref={contents} className="hidden-file" multiple accept="image/jpeg,image/png,image/webp" onChange={e=>{add(e.target.files,'toc');e.target.value='';}}/>
 <div className="photo-upload-grid"><button disabled={busy} className="photo-upload" onClick={()=>cover.current?.click()}><ImagePlus size={26}/><strong>上传封面</strong><small>书名、作者、版次</small></button><button disabled={busy} className="photo-upload" onClick={()=>contents.current?.click()}><BookOpen size={26}/><strong>上传目录页</strong><small>可多选 · 最多5张</small></button></div>
 {photos.length>0&&<div className="photo-previews">{photos.map((p,i)=><div key={i}><img src={p.data} alt={`${p.role==='cover'?'封面':'目录'}：${p.name}`}/><span>{p.role==='cover'?'封面':`目录 ${photos.slice(0,i+1).filter(x=>x.role==='toc').length}`}</span><button disabled={busy} aria-label={`移除${p.name}`} onClick={()=>setPhotos(v=>v.filter((_,n)=>i!==n))}><Trash2 size={13}/></button></div>)}</div>}
 <div className="recognize-actions"><button className="primary-button" disabled={busy||!photos.some(p=>p.role==='toc')} onClick={recognize}>{busy?<LoaderCircle className="spin" size={16}/>:<ImagePlus size={16}/>}识别封面和目录</button><button disabled={busy} className="text-button" onClick={onSettings}><Settings2 size={15}/>图片识别设置</button></div><p className="form-note">点击识别时，所选图片将发送给你配置的图片模型，可能产生API费用。也可跳过识别，直接填写以下内容。</p>
 <div className="onboard-step"><b>2</b><div><h3>校对书目信息和目录</h3><p>{recognized?'已完成图片识别。请检查漏字、章名与层级，补齐遗漏的目录页。':'支持直接粘贴目录文字；不要求上传整本书。'}</p></div></div>
 <label>书名或科目<input disabled={busy} placeholder="例如：高等数学、Python编程入门、世界历史" value={title} onChange={e=>setTitle(e.target.value)}/></label><div className="book-fields"><label>作者<input disabled={busy} placeholder="选填，按封面填写" value={author} onChange={e=>setAuthor(e.target.value)}/></label><label>版次<input disabled={busy} placeholder="选填，例如：第3版" value={edition} onChange={e=>setEdition(e.target.value)}/></label></div>
 <div className="book-fields"><label>学科领域<select disabled={busy} value={field} onChange={e=>setField(e.target.value as StudyField|'auto')}><option value="auto">自动识别{title.trim()?`（${fieldOptions.find(option=>option.value===inferField(title))?.label||'其他'}）`:''}</option>{fieldOptions.map(option=><option key={option.value} value={option.value}>{option.label}</option>)}</select></label><label>学习基础<select disabled={busy} value={level} onChange={e=>setLevel(e.target.value)}><option value="零基础">零基础</option><option value="已有基础">已有基础</option></select></label></div>
 <label>目录（一行一个章节或小节）<textarea rows={9} disabled={busy} value={toc} onChange={e=>setToc(e.target.value)} placeholder={'第一章 函数与极限\n1.1 函数\n1.2 极限\n第二章 导数与微分\n2.1 导数的概念\n\n也支持：Chapter One / Unit II / 1 章节标题'}/></label>
 {toc.trim()&&<div className="toc-preview"><strong>结构预览 · {chapters.length} 章 / 组，{count} 个学习单元</strong>{chapters.map(c=><details key={c.id} open><summary>{c.title}</summary>{c.sections.map((s,i)=><p key={i}>└ {s}</p>)}</details>)}<small>支持中文章、篇、部，英文Chapter、Unit、Part，以及1 / 1.1等编号。请核对预览，只创建你提供的目录，不自动猜补。</small></div>}
 <div className="onboard-step"><b>3</b><div><h3>建立路线，开始第一课</h3><p>创建后选择任一小节，按你选择的基础编写讲解。你可以随时回到这里补全目录。</p></div></div>
 <div className="scope-box"><p>封面和目录足够建立学习结构。它们不包含书中所有细节，生成讲解属于通用知识教学，不会冒充该版教材原文或虚构页码。</p></div>
 {error&&<p className="form-error" role="alert">{error}</p>}
 <button className="primary-button full" disabled={busy||!title.trim()||!count} onClick={()=>onApply({title:title.trim(),author:author.trim(),edition:edition.trim(),toc,importedOn:new Date().toISOString(),field:field==='auto'?inferField(title):field,level},topicsFromContents(chapters))}><Check size={17}/>{actionLabel}</button>
 <button className="text-button restore-backup" disabled={busy} onClick={onBackup}>导入之前的JSON学习备份</button>
 </div>;
}
