'use client';
import {BookOpen,CheckCircle2,Lightbulb,LoaderCircle,Sparkles} from 'lucide-react';
import type {Topic} from '@/lib/learning-data';
import LessonText from './LessonText';
import {beginnerLesson} from '@/lib/beginner-lessons';
export default function BeginnerLesson({topic,onGenerate,generating}:{topic:Topic;onGenerate:()=>void;generating:boolean}){
 const lesson=topic.lesson||(topic.sourceType==='课程主题示例'?beginnerLesson(topic.id):undefined);
 if(!lesson)return <section className="lesson-pending"><BookOpen size={28}/><h3>从这个主题开始一堂完整的课</h3><p>{topic.explanation}</p><div className="lesson-preview"><span>01 认识术语</span><span>02 逐步讲解</span><span>03 跟做例题</span><span>04 检查理解</span></div><button className="primary-button" onClick={onGenerate} disabled={generating}>{generating?<LoaderCircle className="spin" size={17}/>:<Sparkles size={17}/>}编写本节入门课</button><small>使用模型设置中的API服务；仅发送书目信息、目录与本节主题。</small></section>;
 const chars=JSON.stringify(lesson).length,minutes=Math.max(6,Math.round(chars/180));
 return <div className="beginner-lesson"><div className="lesson-meta"><span><BookOpen size={14}/>零基础入门</span><span>约 {minutes}–{minutes+3} 分钟 · 可随时停下来练习</span></div><div className="lesson-goal"><CheckCircle2 size={20}/><div><strong>学完这一节，你能做到</strong><p>{lesson.goal}</p></div></div>
 <section className="lesson-section"><div className="lesson-kicker">01 / 从一个问题开始</div><h3>先理解为什么要学它</h3><p>{lesson.opening}</p></section>
 <section className="lesson-section"><div className="lesson-kicker">02 / 先认识这些词</div><h3>不默认你已经会了</h3><dl className="term-list">{lesson.terms.map(t=><div key={t.name}><dt>{t.name}</dt><dd>{t.meaning}</dd></div>)}</dl></section>
 <section className="lesson-section"><div className="lesson-kicker">03 / 一步一步弄明白</div><h3>把过程拆开看</h3><div className="teaching-steps">{lesson.steps.map((s,i)=><div className="teaching-step" key={i}><span>{i+1}</span><div><h4>{s.title}</h4><LessonText text={s.body}/></div></div>)}</div></section>
 <section className="worked-example"><div className="lesson-kicker"><Lightbulb size={15}/>04 / 跟着做一个例子</div><h3>{lesson.example.question}</h3><strong>怎么想</strong><LessonText text={lesson.example.reasoning}/><div><strong>得到结论</strong><LessonText text={lesson.example.answer}/></div></section>
 <section className="lesson-section comprehension"><div className="lesson-kicker">05 / 现在试着用自己的话说</div><h3>理解检查</h3><p className="muted">先想一想，再展开答案。答错时回看相关步骤即可。</p>{lesson.checks.map((c,i)=><details key={`${topic.id}-${i}`}><summary><span>{i+1}</span>{c.question}<small>查看讲解</small></summary><LessonText text={c.answer}/></details>)}</section>
 <div className="lesson-references"><strong>延伸阅读与核对</strong><p>{topic.sourceType?.includes('示例')?'这是通用入门示例，不是指定教材原文。':'讲解围绕当前主题另行编写，不是教材原文。'}课程总页用于继续学习，不能视为每句话的逐条证据。</p>{lesson.references.map((r,i)=><a href={r.url} target="_blank" rel="noreferrer" key={i}>{r.title} ↗</a>)}</div>
 <button className="quiet-button deeper-lesson" disabled={generating} onClick={onGenerate}>{generating?<LoaderCircle className="spin" size={16}/>:<Sparkles size={16}/>}针对本节编写更详细的讲解</button>
 </div>;
}
