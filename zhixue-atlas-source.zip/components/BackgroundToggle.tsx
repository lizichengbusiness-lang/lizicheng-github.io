'use client';
import {useEffect,useState} from 'react';
import {Image as ImageIcon} from 'lucide-react';
const KEY='zhixue-science-background-v1';
export default function BackgroundToggle(){
 const [enabled,setEnabled]=useState(true),[ready,setReady]=useState(false);
 useEffect(()=>{try{setEnabled(localStorage.getItem(KEY)!=='off');}catch{}setReady(true);},[]);
 useEffect(()=>{if(!ready)return;document.documentElement.dataset.studyBackground=enabled?'on':'off';try{localStorage.setItem(KEY,enabled?'on':'off');}catch{}},[ready,enabled]);
 return <button className="background-toggle" role="switch" aria-label="学科背景" aria-checked={enabled} title="开启或关闭页面与导图的学科背景" onClick={()=>setEnabled(v=>!v)}><ImageIcon size={15}/><span>学科背景</span><i aria-hidden="true"><b/></i><small>{enabled?'开':'关'}</small></button>;
}
