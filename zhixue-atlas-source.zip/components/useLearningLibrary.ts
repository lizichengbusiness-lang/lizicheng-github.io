'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  createDefaultLibrary, createSpace, LEGACY_STORAGE_KEY, LIBRARY_STORAGE_KEY, mergeLibraries,
  parseLibrary, serializeLibrary, updateLibrarySpace, type LearningLibrary, type LearningSpace, type SpaceUpdate,
} from '@/lib/library-store';

export function useLearningLibrary() {
  const [library, setLibrary] = useState<LearningLibrary>(createDefaultLibrary);
  const [ready, setReady] = useState(false);
  const [storageError, setStorageError] = useState('');
  // If the existing JSON is damaged, leave it untouched until the learner explicitly changes data.
  const canPersist = useRef(true);

  useEffect(() => {
    try {
      const current = window.localStorage.getItem(LIBRARY_STORAGE_KEY);
      const legacy = current === null ? window.localStorage.getItem(LEGACY_STORAGE_KEY) : null;
      if (current !== null || legacy !== null) setLibrary(parseLibrary(current ?? legacy));
    } catch {
      canPersist.current = false;
      setStorageError('本地学习库暂时无法读取，已打开示例。原有记录仍保留，可导入导出的备份；本次修改仍可在当前页面使用。');
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready || !canPersist.current) return;
    try {
      window.localStorage.setItem(LIBRARY_STORAGE_KEY, serializeLibrary(library));
      setStorageError('');
    } catch {
      setStorageError('浏览器存储空间不足或存储不可用。本次内容仍在页面中，请导出完整学习库备份。');
    }
  }, [library, ready]);

  const updateById = useCallback((id: string, update: SpaceUpdate) => {
    canPersist.current = true;
    setLibrary((current) => updateLibrarySpace(current, id, update));
  }, []);

  const activateSpace = useCallback((id: string) => {
    canPersist.current = true;
    setLibrary((current) => current.spaces.some((space) => space.id === id) ? { ...current, activeId: id } : current);
  }, []);

  const addSpace = useCallback((input: LearningSpace) => {
    const space = createSpace(input);
    canPersist.current = true;
    setLibrary((current) => {
      const merged = mergeLibraries(current, { schemaVersion: 3, activeId: space.id, spaces: [space] });
      return { ...merged, activeId: merged.spaces[merged.spaces.length - 1].id };
    });
  }, []);

  const importLibrary = useCallback((raw: unknown): number => {
    const incoming = parseLibrary(raw);
    canPersist.current = true;
    setLibrary((current) => mergeLibraries(current, incoming));
    return incoming.spaces.length;
  }, []);

  const space = library.spaces.find((item) => item.id === library.activeId) || library.spaces[0];
  return { library, space, ready, storageError, updateById, activateSpace, addSpace, importLibrary };
}

export default useLearningLibrary;
