import { POST as modelPost } from '../app/api/model/route';
import { POST as coursesPost } from '../app/api/courses/route';

export type ApiEnvironment = { ALLOWED_ORIGINS?: string };
export type ApiHandler = (request: Request) => Response | Promise<Response>;
export type ApiHandlers = { model: ApiHandler; courses: ApiHandler };

function allowedOrigins(value: string | undefined): Set<string> {
  const origins = new Set<string>();
  for (const entry of (value || '').split(',')) {
    const candidate = entry.trim();
    try {
      const url = new URL(candidate);
      const local = ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname);
      // A serialized origin has no path, credentials, query, hash or wildcard.
      if (url.origin !== candidate || url.hostname.includes('*') || url.username || url.password) continue;
      if (url.protocol === 'https:' || (url.protocol === 'http:' && local)) origins.add(candidate);
    } catch { /* Invalid configuration entries never broaden access. */ }
  }
  return origins;
}

function decorate(response: Response, origin?: string, preflight = false): Response {
  const headers = new Headers(response.headers);
  for (const name of [...headers.keys()]) if (name.toLowerCase().startsWith('access-control-')) headers.delete(name);
  headers.set('Cache-Control', 'no-store');
  const vary = (headers.get('Vary') || '').split(',').map(v => v.trim()).filter(Boolean);
  if (!vary.some(v => v.toLowerCase() === 'origin')) vary.push('Origin');
  headers.set('Vary', vary.join(', '));
  if (origin) {
    headers.set('Access-Control-Allow-Origin', origin);
    if (preflight) {
      headers.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
      headers.set('Access-Control-Allow-Headers', 'Content-Type');
    }
  }
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

const json = (error: string, status: number, origin?: string, extraHeaders?: HeadersInit) =>
  decorate(Response.json({ error }, { status, headers: extraHeaders }), origin);

/** Injection keeps wrapper tests independent of model credentials and network access. */
export function createApiWorker(overrides: Partial<ApiHandlers> = {}) {
  const handlers: ApiHandlers = { model: modelPost, courses: coursesPost, ...overrides };
  return {
    async fetch(request: Request, env: ApiEnvironment): Promise<Response> {
      const origin = request.headers.get('Origin');
      const allowed = origin !== null && allowedOrigins(env.ALLOWED_ORIGINS).has(origin);
      const path = new URL(request.url).pathname;
      const isHealth = path === '/health';
      // Browser API access fails closed, including opaque or missing origins.
      // Origin-less GET /health remains available to deployment health checks.
      if (!allowed && !(origin === null && isHealth && request.method === 'GET')) return json('此来源未获允许，请检查API的ALLOWED_ORIGINS配置。', 403);
      const corsOrigin = allowed ? origin! : undefined;
      const handler = path === '/api/model' ? handlers.model : path === '/api/courses' ? handlers.courses : undefined;
      if (!isHealth && !handler) return json('接口不存在。', 404, corsOrigin);

      if (request.method === 'OPTIONS') {
        const expected = isHealth ? 'GET' : 'POST';
        if (request.headers.get('Access-Control-Request-Method')?.toUpperCase() !== expected) return json('预检请求的方法不受支持。', 405, corsOrigin, { Allow: `${expected}, OPTIONS` });
        const requestedHeaders = (request.headers.get('Access-Control-Request-Headers') || '').split(',').map(h => h.trim().toLowerCase()).filter(Boolean);
        if (requestedHeaders.some(h => h !== 'content-type')) return json('预检请求的头字段不受支持。', 403, corsOrigin);
        return decorate(new Response(null, { status: 204 }), corsOrigin, true);
      }

      if (isHealth) return request.method === 'GET'
        ? decorate(Response.json({ ok: true, service: 'zhixue-learning-api' }), corsOrigin)
        : json('请求方法不受支持。', 405, corsOrigin, { Allow: 'GET, OPTIONS' });
      if (request.method !== 'POST') return json('请求方法不受支持。', 405, corsOrigin, { Allow: 'POST, OPTIONS' });
      try {
        return decorate(await handler!(request), corsOrigin);
      } catch {
        // Provider exceptions and request bodies can contain credentials. Never echo them.
        return json('接口暂时不可用，请稍后重试。', 502, corsOrigin);
      }
    },
  };
}

export default createApiWorker();
