# GitHub Pages 部署与更新

本项目的网页可以发布在GitHub Pages，AI等联网功能由独立后端提供。以下说明对应仓库 `lizichengbusiness-lang/lizicheng-github.io` 的源码ZIP发布方式。

## 仓库中的文件

- `zhixue-atlas-source.zip`：完整可编辑源码；ZIP内的顶层是 `package.json` 和各源码目录。
- `.github/workflows/pages.yml`：构建与发布流程。把ZIP解压到 `site-source/` 后，安装依赖、运行 `npm run build:pages`，将 `site-source/dist-pages/` 发布到Pages。

网站最终地址以仓库 `Settings → Pages` 或成功部署记录中的链接为准。此仓库是项目仓库，通常路径为 `https://lizichengbusiness-lang.github.io/lizicheng-github.io/`。仓库名包含 `github.io` 并不意味着它自动成为账号主页；只有与账号名称匹配的 `账号.github.io` 才使用根路径。

## 首次发布

1. 确认仓库中已有上述ZIP和工作流，ZIP不加额外包裹目录。
2. 打开仓库 `Settings → Pages`，将 `Build and deployment → Source` 设为 `GitHub Actions`。
3. 打开 `Actions`，查看Pages工作流；如需手动触发，点击 `Run workflow`。
4. 等构建和发布均成功后，打开部署记录提供的网站链接。若构建失败，进入失败步骤查看日志，修正后重新提交或运行。

工作流只发布静态网页，不会自动部署Cloudflare后端。

## 下载源码与本地修改

在GitHub中下载 `zhixue-atlas-source.zip` 并解压。进入包含 `package.json` 的目录，使用Node.js 24运行：

```powershell
npm ci
npm run build:pages
npm run preview:pages
```

`build:pages` 使用 `vite.pages.config.ts`，产物在 `dist-pages/`。本地预览地址与路径以命令输出为准；项目路径默认包含 `/lizicheng-github.io/`。

常用源码位置：

- `app/page.tsx`：学习工作台及设置界面。
- `components/KnowledgeAtlas.tsx`：可聚焦的思维导图。
- `lib/library-store.ts`：多学习空间与备份格式。
- `lib/subject-catalog.ts`：科目分类与入门示例。
- `github/pages/`：GitHub Pages静态网页入口。
- `github/api-worker.ts`：独立后端入口。

修改完成后，将源码根目录中的文件重新压成 `zhixue-atlas-source.zip`，在仓库中上传并替换同名文件，提交后查看Actions。源码ZIP内保留锁文件，排除 `node_modules/`、`dist/`、`dist-pages/`、`.git/`、临时目录、个人学习备份及密钥文件。不要把最外层解压文件夹一起压进去，否则工作流找不到 `site-source/package.json`。

如果将来希望直接在GitHub浏览、编辑单个源码文件，可以把ZIP展开后的源码提交到仓库，再把工作流的安装目录改成源码所在目录，取消解压步骤。当前工作流按ZIP布局执行。

## 路径配置

工作流中的 `GITHUB_REPOSITORY` 用于确定静态资源的基础路径：项目仓库使用 `/仓库名/`，账号主页仓库使用 `/`。换仓库或绑定独立域名时，可以在构建环境设置 `STUDY_BASE_PATH` 覆盖，例如根路径 `/`。修改这个变量后需要重新构建发布，不能只移动已经生成的文件。

## 配置联网功能的后端

GitHub Pages本身无法执行 `/api/model` 或 `/api/courses`。没有后端时，示例课、图谱、手动粘贴目录、笔记、收藏、全库备份及YouTube/B站外链仍可使用。图片识别、AI生成框架和讲解、答疑以及站内自动找课需要独立后端。

提供的Cloudflare Worker复用现有接口。部署步骤：

1. 在 `github/wrangler.api.jsonc` 的 `ALLOWED_ORIGINS` 中填写 `https://lizichengbusiness-lang.github.io`。只填来源，不加 `/lizicheng-github.io/`、末尾斜杠或通配符；多个来源用英文逗号分隔。
2. 登录自己的Cloudflare账号，在源码根目录运行以下命令部署：

```powershell
npx wrangler login
npx wrangler deploy --config github/wrangler.api.jsonc
```

3. 访问命令返回的Worker地址加 `/health`，应看到包含 `ok: true` 的状态信息。
4. 在网页“模型与搜索设置”中，将“后端服务地址”填为Worker的HTTPS源地址，例如 `https://你的服务.workers.dev`；不要附加 `/api`、仓库名或其他路径。
5. 在同一设置窗口填入自己账号可用的模型名称、API密钥，以及按需使用的图片模型或YouTube密钥。刷新页面后需要重新配置。

`ALLOWED_ORIGINS` 为空时，网站API调用默认被拒绝。健康检查成功只说明服务可达；若网页仍提示来源未获允许，应核对上述来源配置并重新部署后端。模型密钥从页面会话随请求发往后端和所选服务商，不写入源码ZIP、GitHub工作流或学习备份。

原来的私有Sites网址不能直接当成现成的跨域后端；请填写自己部署或信任并且正确配置CORS的服务。

## 把旧站学习记录迁到新站

浏览器按网站来源分别保存学习记录。原 `chatgpt.site` 与新的 `github.io` 来源不同，无法自动互相读取。

1. 在旧站导出完整学习库JSON备份。
2. 在GitHub Pages新站打开“书架与科目”，选择导入备份。
3. 确认书籍、笔记、收藏与进度已经出现在书架中。导入会合并项目，同ID项目会作为副本保留，不覆盖现有项目。

模型密钥、后端设置与图片草稿不会进入备份，需在新站重新设置。同一来源中已有的旧版单书记录会自动迁移到新版多学习空间，不删除旧存储键。
