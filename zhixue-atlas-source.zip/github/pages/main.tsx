import {createRoot} from 'react-dom/client';
import Home from '../../app/page';
import '../../app/globals.css';
import '../../app/learning.css';
import '../../app/mindmap.css';
import '../../app/interaction-theme.css';
import '../../app/visual-theme.css';
import '../../app/library.css';
createRoot(document.getElementById('root')!).render(<Home/>);
