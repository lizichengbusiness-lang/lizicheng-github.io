import type { Metadata } from "next";
import "./globals.css";
import "./learning.css";
import "./mindmap.css";
import "./interaction-theme.css";
import "./visual-theme.css";
import "./library.css";

export const metadata: Metadata = {
  title: "知学图谱 · 书籍与科目学习工作台",
  description: "从封面、目录或科目名称开始，建立独立的学习路线、讲解、思维导图与课程入口。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">{children}</body>
    </html>
  );
}
