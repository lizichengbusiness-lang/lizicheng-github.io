import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const project=fileURLToPath(new URL('.',import.meta.url));
const repository=process.env.GITHUB_REPOSITORY?.split('/')[1]||'lizicheng-github.io';
const rawBase=process.env.STUDY_BASE_PATH||(repository.endsWith('.github.io')&&repository===process.env.GITHUB_REPOSITORY?.split('/')[0]+'.github.io'?'/':`/${repository}/`);
const base='/'+rawBase.replace(/^\/+|\/+$/g,'')+(rawBase==='/'?'':'/');
export default defineConfig({
 root:path.join(project,'github/pages'),base,publicDir:path.join(project,'public'),
 resolve:{alias:{'@':project}},plugins:[react()],
 define:{__STUDY_STATIC__:'true',__STUDY_BASE_PATH__:JSON.stringify(base)},
 build:{outDir:path.join(project,'dist-pages'),emptyOutDir:true,assetsDir:'',sourcemap:false},
 server:{host:'127.0.0.1',port:5174},
});
