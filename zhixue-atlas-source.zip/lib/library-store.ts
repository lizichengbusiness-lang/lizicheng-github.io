import { initialCourses, sampleTopics, type Course, type Topic } from './learning-data';
import { parseCourseUrl, validateTopics, type SourceDocument } from './learning-utils';
import type { BookPlan } from './curriculum';
import { fieldOptions, inferField, type StudyField } from './subject-catalog';

export type LearningSpace = {
  id: string;
  title: string;
  mode: 'book' | 'subject' | 'sample';
  field: StudyField;
  level: string;
  topics: Topic[];
  courses: Course[];
  bookPlan: BookPlan | null;
  source: SourceDocument | null;
  kind: string;
  learned: string[];
  saved: string[];
  notes: Record<string, string>;
  selected: string;
  updatedAt: string;
};

export type LearningLibrary = { schemaVersion: 3; activeId: string; spaces: LearningSpace[] };
export type SpaceUpdate = Partial<LearningSpace> | ((space: LearningSpace) => Partial<LearningSpace> | LearningSpace);

export const LIBRARY_STORAGE_KEY = 'zhixue-library-v3';
export const LEGACY_STORAGE_KEY = 'zhixue-atlas-v1';
export const SAMPLE_SPACE_ID = 'sample-biochemistry';

const record = (value: unknown): Record<string, unknown> =>
  value !== null && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};
const string = (value: unknown, fallback = '') => typeof value === 'string' ? value : fallback;
const strings = (value: unknown) => Array.isArray(value) ? [...new Set(value.filter((item): item is string => typeof item === 'string'))] : [];
const freshId = () => `space-${globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`}`;
const timestamp = (value: unknown) => typeof value === 'string' && !Number.isNaN(Date.parse(value)) ? value : new Date().toISOString();

function normalizeField(value: unknown, title: string): StudyField {
  // Options are the single source of truth for persisted discipline values.
  const fields: readonly unknown[] = fieldOptions;
  const valid = fields.some((entry) => typeof entry === 'string' ? entry === value : record(entry).value === value);
  return valid ? value as StudyField : inferField(title);
}

function normalizeTopics(value: unknown): Topic[] {
  if (!Array.isArray(value)) return [];
  const valid = value.flatMap((item, index) => {
    try { return validateTopics([item], `import-${index}`); }
    catch {
      // A damaged optional lesson must not discard a learner's valid topic or notes.
      const raw = record(item);
      if (!raw.lesson) return [];
      try { return validateTopics([{ ...raw, lesson: undefined }], `import-${index}`); }
      catch { return []; }
    }
  });
  const used = new Set<string>();
  return valid.map((topic, index) => {
    const original = topic.id || `import-${index}`;
    let id = original, suffix = 1;
    // A suffix may itself already be another topic id in an imported backup.
    while (used.has(id)) id = `${original}-${suffix++}`;
    used.add(id);
    return id === topic.id ? topic : { ...topic, id };
  });
}

function httpsUrl(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  try { const url = new URL(value); return url.protocol === 'https:' && !url.username && !url.password ? url.href : undefined; }
  catch { return undefined; }
}

function normalizeCourses(value: unknown): Course[] {
  if (!Array.isArray(value)) return [];
  const usedUrls = new Set<string>(), usedIds = new Set<string>();
  return value.flatMap((item, index) => {
    const raw = record(item);
    try {
      const parsed = parseCourseUrl(string(raw.url));
      if (!parsed.url || usedUrls.has(parsed.url)) return [];
      usedUrls.add(parsed.url);
      let id = string(raw.id).trim() || `course-${index + 1}`;
      while (usedIds.has(id)) id += `-${index + 1}`;
      usedIds.add(id);
      return [{
        id, title: string(raw.title, '未命名课程'), school: string(raw.school, '用户收集'),
        teacher: string(raw.teacher, '待核对'), language: string(raw.language, '待核对'),
        note: string(raw.note), status: string(raw.status, '用户收集 · 待核对'), topics: strings(raw.topics),
        platform: parsed.platform!, url: parsed.url,
        ...(parsed.playlistId ? { playlistId: parsed.playlistId } : {}),
        ...(parsed.videoId ? { videoId: parsed.videoId } : {}),
        ...(parsed.bvid ? { bvid: parsed.bvid } : {}),
        ...(httpsUrl(raw.official) ? { official: httpsUrl(raw.official) } : {}),
      }];
    } catch { return []; }
  });
}

function normalizePlan(value: unknown, title: string): BookPlan | null {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const raw = record(value);
  return {
    title: string(raw.title, title), author: string(raw.author), edition: string(raw.edition),
    toc: string(raw.toc), importedOn: timestamp(raw.importedOn),
    ...(typeof raw.field === 'string' ? { field: normalizeField(raw.field, title) } : {}),
    ...(typeof raw.level === 'string' ? { level: raw.level } : {}),
  };
}

function normalizeSource(value: unknown): SourceDocument | null {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const raw = record(value);
  if (typeof raw.text !== 'string') return null;
  return {
    name: string(raw.name, '导入资料'), text: raw.text, importedOn: timestamp(raw.importedOn),
    ...(typeof raw.pages === 'number' && Number.isFinite(raw.pages) && raw.pages >= 0 ? { pages: raw.pages } : {}),
  };
}

function normalizeSpace(value: unknown, fallbackId?: string): LearningSpace {
  const raw = record(value);
  const title = string(raw.title).trim() || '未命名学习';
  const topics = normalizeTopics(raw.topics), bookPlan = normalizePlan(raw.bookPlan, title);
  const mode = raw.mode === 'book' || raw.mode === 'subject' || raw.mode === 'sample' ? raw.mode : bookPlan ? 'book' : 'subject';
  const topicIds = new Set(topics.map((topic) => topic.id));
  // Notes are keyed by topic id; prototype keys cannot be used as topic ids in this mapping.
  const notes: Record<string, string> = {};
  for (const [key, value] of Object.entries(record(raw.notes))) {
    if (typeof value === 'string' && key !== '__proto__' && key !== 'constructor' && key !== 'prototype') notes[key] = value;
  }
  const selected = typeof raw.selected === 'string' && topicIds.has(raw.selected)
    ? raw.selected : topics.some((topic) => topic.id === 'glycolysis') ? 'glycolysis' : topics[0]?.id || '';
  return {
    id: string(raw.id).trim() || fallbackId || freshId(), title, mode,
    field: normalizeField(raw.field ?? record(raw.bookPlan).field, title),
    level: string(raw.level, string(record(raw.bookPlan).level, '零基础')) || '零基础',
    topics, courses: normalizeCourses(raw.courses), bookPlan, source: normalizeSource(raw.source),
    kind: string(raw.kind, mode === 'sample' ? '示例主题框架' : bookPlan ? '封面与目录建立' : '科目学习空间'),
    learned: strings(raw.learned), saved: strings(raw.saved), notes, selected, updatedAt: timestamp(raw.updatedAt),
  };
}

/** New disciplines start empty: no biochemistry topics or courses are silently added. */
export function createSpace(input: Partial<LearningSpace> & { title: string }): LearningSpace {
  return normalizeSpace(input);
}

export function createDefaultLibrary(): LearningLibrary {
  const sample = createSpace({
    id: SAMPLE_SPACE_ID, title: '动物生物化学', mode: 'sample', level: '零基础',
    topics: sampleTopics, courses: initialCourses, selected: 'glycolysis', kind: '示例主题框架',
  });
  return { schemaVersion: 3, activeId: sample.id, spaces: [sample] };
}

/** Accepts both a v3 library and a legacy v1/v2 single-book backup. Unknown keys are discarded. */
export function parseLibrary(raw: unknown): LearningLibrary {
  const input = typeof raw === 'string' ? JSON.parse(raw) as unknown : raw;
  const data = record(input);
  if (typeof data.schemaVersion === 'number' && data.schemaVersion > 3) throw new Error('此学习库由更新版本创建，请使用相应版本打开，避免丢失新格式中的资料。');
  if (Array.isArray(data.spaces)) {
    if (!data.spaces.length) throw new Error('学习备份中没有学习空间。');
    const used = new Set<string>();
    const spaces = data.spaces.map((value) => {
      if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('学习空间格式无效。');
      const space = normalizeSpace(value);
      if (used.has(space.id)) space.id = freshId();
      used.add(space.id);
      return space;
    });
    const activeId = typeof data.activeId === 'string' && spaces.some((space) => space.id === data.activeId) ? data.activeId : spaces[0].id;
    return { schemaVersion: 3, activeId, spaces };
  }
  if (!Array.isArray(data.topics) && !Array.isArray(data.courses)) throw new Error('请选择学习库备份或旧版单书学习备份。');
  const isSample = data.title === '动物生物化学' && /示例/.test(string(data.kind));
  const space = normalizeSpace({ ...data, mode: isSample ? 'sample' : data.bookPlan ? 'book' : 'subject' }, isSample ? SAMPLE_SPACE_ID : undefined);
  return { schemaVersion: 3, activeId: space.id, spaces: [space] };
}

/** Imported id collisions get a new id; existing learner progress is never overwritten. */
export function mergeLibraries(current: LearningLibrary, incoming: LearningLibrary): LearningLibrary {
  const base = parseLibrary(current), extra = parseLibrary(incoming);
  const used = new Set(base.spaces.map((space) => space.id));
  const additions = extra.spaces.map((space) => {
    let id = space.id;
    while (used.has(id)) id = freshId();
    used.add(id);
    return { ...space, id };
  });
  return { schemaVersion: 3, activeId: base.activeId, spaces: [...base.spaces, ...additions] };
}

/** Always address the captured id, so a late async result cannot mutate another active book. */
export function updateLibrarySpace(library: LearningLibrary, id: string, update: SpaceUpdate): LearningLibrary {
  const index = library.spaces.findIndex((space) => space.id === id);
  if (index < 0) return library;
  const previous = library.spaces[index];
  const patch = typeof update === 'function' ? update(previous) : update;
  const next = normalizeSpace({ ...previous, ...patch, id: previous.id, updatedAt: new Date().toISOString() });
  const spaces = library.spaces.slice();
  spaces[index] = next;
  return { schemaVersion: 3, activeId: library.activeId, spaces };
}

/** Revalidate the complete structure before export; API settings and image drafts have no schema fields. */
export function serializeLibrary(library: LearningLibrary): string {
  return JSON.stringify(parseLibrary(library), null, 2);
}
