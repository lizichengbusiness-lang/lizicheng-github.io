import type { Topic } from './learning-data';
import type { BookPlan } from './curriculum';
import type { LearningSpace } from './library-store';
import { beginnerLesson } from './beginner-lessons';
import { inferField } from './subject-catalog';

const chineseNumber = '[一二三四五六七八九十百千万零〇两\\d]+';
const smallNumber = 'one|two|three|four|five|six|seven|eight|nine';
const tens = `(?:twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety)(?:[ -](?:${smallNumber}))?`;
const cardinal = `(?:${smallNumber}|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen)`;
const englishNumber = `(?:\\d+(?:\\.\\d+)*|[ivxlcdm]+|(?:${smallNumber}) hundred(?: (?:and )?(?:${tens}|${cardinal}))?|${tens}|${cardinal}|first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth|eleventh|twelfth|twentieth)`;
const chinesePrefix = new RegExp(`^第\\s*${chineseNumber}\\s*[章节篇部][\\s:：、.．—-]*`, 'i');
const englishPrefix = new RegExp(`^(?:chapter|unit|part)\\s+${englishNumber}(?=$|[\\s:：、.．—-])[\\s:：、.．—-]*`, 'i');

function heading(value: string): string {
  const original = value.normalize('NFKC').trim().toLowerCase().replace(/\s+/g, ' ');
  // Only strip structural prefixes. "2D graphics" and "1984" remain actual titles.
  const plain = original.replace(chinesePrefix, '').replace(englishPrefix, '')
    .replace(/^\d+(?:\s*\.\s*\d+)*(?:[、.:)\-]+\s*|\s+)/, '').trim();
  return plain || original;
}

function indexBy(items: Topic[], key: (topic: Topic) => string): Map<string, number[]> {
  const index = new Map<string, number[]>();
  items.forEach((topic, i) => {
    const name = key(topic), matches = index.get(name);
    if (matches) matches.push(i); else index.set(name, [i]);
  });
  return index;
}

/** Revise only the confirmed contents; keep learner work where the identity is unambiguous. */
export function reviseContents(space: LearningSpace, plan: BookPlan, items: Topic[]): Partial<LearningSpace> {
  const oldByNew = new Map<number, Topic>(), usedOld = new Set<number>();
  const exactKey = (topic: Topic) => JSON.stringify([heading(topic.title), heading(topic.group)]);
  const exactOld = indexBy(space.topics, exactKey), exactNew = indexBy(items, exactKey);
  function match(oldIndex: number, newIndex: number) {
    if (usedOld.has(oldIndex) || oldByNew.has(newIndex)) return;
    usedOld.add(oldIndex); oldByNew.set(newIndex, space.topics[oldIndex]);
  }
  // Duplicate rows inside the same chapter are ambiguous too: do not assign notes by order.
  for (const [key, newMatches] of exactNew) {
    const oldMatches = exactOld.get(key);
    if (oldMatches?.length === 1 && newMatches.length === 1) match(oldMatches[0], newMatches[0]);
  }
  const oldTitles = indexBy(space.topics, topic => heading(topic.title));
  const newTitles = indexBy(items, topic => heading(topic.title));
  for (const [key, newMatches] of newTitles) {
    const oldMatches = oldTitles.get(key);
    // Counts are global, including already matched rows. Removing one duplicate must
    // never make a different chapter's remaining duplicate appear safe to move.
    if (oldMatches?.length === 1 && newMatches.length === 1) match(oldMatches[0], newMatches[0]);
  }
  const remap = new Map<string, string>();
  for (const [newIndex, old] of oldByNew) remap.set(old.id, items[newIndex].id);
  const topics = items.map((item, i) => {
    const old = oldByNew.get(i);
    if (!old) return item;
    return {
      ...old,
      // Sample lessons used to be resolved by legacy ids. Materialize before ids change.
      lesson: old.lesson || (old.sourceType === '课程主题示例' ? beginnerLesson(old.id) : undefined),
      id: item.id, title: item.title, group: item.group, chapterId: item.chapterId,
      prerequisites: old.prerequisites.flatMap(id => remap.has(id) ? [remap.get(id)!] : []),
    };
  });
  const mappedIds = (ids: string[]) => ids.flatMap(id => remap.has(id) ? [remap.get(id)!] : []);
  return {
    title: plan.title, mode: space.mode === 'subject' ? 'subject' : 'book',
    field: plan.field || inferField(plan.title), level: plan.level || space.level,
    bookPlan: plan, kind: '按确认目录学习', source: null, topics,
    selected: remap.get(space.selected) || topics[0]?.id || '',
    learned: mappedIds(space.learned), saved: mappedIds(space.saved),
    notes: Object.fromEntries(Object.entries(space.notes).flatMap(([id, note]) => remap.has(id) ? [[remap.get(id)!, note]] : [])),
  };
}
