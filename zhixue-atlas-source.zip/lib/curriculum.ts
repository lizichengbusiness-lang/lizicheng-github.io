import type { Topic } from './learning-data';
import type { StudyField } from './subject-catalog';
export type Lesson = {
  goal: string; opening: string; terms: {name:string;meaning:string}[];
  steps: {title:string;body:string}[];
  example: {question:string;reasoning:string;answer:string};
  checks: {question:string;answer:string}[];
  references: {title:string;url:string}[];
};
export type BookPlan = { title:string; author:string; edition:string; toc:string; importedOn:string; field?:StudyField; level?:string };
export type Chapter = {id:string;title:string;sections:string[]};
const englishNumber='(?:\\d+|[ivxlcdm]+|(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred)(?:[ -]+(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred))*|first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth|eleventh|twelfth|twentieth)';
const englishChapter=new RegExp(`^(?:chapter|unit|part)\\s+${englishNumber}(?=$|[\\s:：、–—-]|[.．](?!\\d))`,'i');
const bareEnglishChapter=new RegExp(`^(?:chapter|unit|part)\\s+${englishNumber}$`,'i');
function explicitChapter(row:string):boolean{
  const label=row.normalize('NFKC');
  return /^第\s*[一二三四五六七八九十百千万零〇两\d]+\s*[章篇部]/.test(label)||englishChapter.test(label);
}
function integerHeading(row:string):boolean{
  const label=row.normalize('NFKC');
  if(/^\d+\s*\.\s*\d/.test(label))return false;
  return /^\d+(?:[、.．)）:：](?!\s*\d)\s*|\s+(?!\d))\S/.test(label);
}
function contentsRow(line:string):string{
  let row=line.trim();
  // OCR often separates dot leaders with spaces. Keep section numbering at the start.
  row=row.replace(/(?:[.．·…⋯•‧_—-]\s*){2,}(?:\(?[\d０-９一二三四五六七八九十百零〇ivxlcdm]+\)?)?\s*$/i,'').trim();
  // An isolated "Chapter 1" is a heading, not a title followed by a page number.
  if(!bareEnglishChapter.test(row.normalize('NFKC'))){
    row=row.replace(/(?:\t|\s{2,})\(?[ivxlcdm]+\)?\s*$/i,'').replace(/\s+\(?[\d０-９]+(?:[-–][\d０-９]+)?\)?\s*$/,'').trim();
  }
  return row;
}
// Preserve the supplied order and titles; never infer missing chapters or sections.
export function parseContents(text:string):Chapter[]{
  const rows=text.split(/\r?\n/).map(contentsRow).filter(row=>row&&!/^(?:目录|目次|contents|table of contents)$/i.test(row)&&!/^\d+$/.test(row));
  const hasExplicitChapters=rows.some(explicitChapter);
  const out:Chapter[]=[];
  for(const row of rows){
    const chapter=explicitChapter(row)||(!hasExplicitChapters&&integerHeading(row));
    if(chapter||!out.length)out.push({id:`chapter-${out.length+1}`,title:row,sections:[]});
    else out[out.length-1].sections.push(row);
  }
  return out;
}
export function topicsFromContents(chapters:Chapter[]):Topic[]{
  return chapters.flatMap((c)=> (c.sections.length?c.sections:[c.title]).map((name,i)=>({
    id:`${c.id}-section-${i+1}`,title:name,group:c.title,brief:'从零开始，先理解概念，再逐步学习原理与应用。',
    explanation:'本节已经按你确认的目录建立。点击“编写本节入门课”后，将围绕这个主题编写术语解释、逐步推导、实例与理解练习。目录仅提供学习结构，讲解另行编写。',
    points:[],misconception:'',prerequisites:[],tags:[name],sourceType:'目录已校对 · 讲解待编写',chapterId:c.id,
  })));
}
export function validateLesson(raw:unknown):Lesson {
  if(!raw||typeof raw!=='object')throw new Error('讲解格式无效');
  const r=raw as Record<string,unknown>;
  const string=(v:unknown)=>typeof v==='string'?v.trim():'';
  const records=(v:unknown)=>Array.isArray(v)?v.filter((x):x is Record<string,unknown>=>!!x&&typeof x==='object'):[];
  const terms=records(r.terms).map(t=>({name:string(t.name),meaning:string(t.meaning)})).filter(t=>t.name&&t.meaning);
  const steps=records(r.steps).map(t=>({title:string(t.title),body:string(t.body)})).filter(t=>t.title&&t.body);
  const checks=records(r.checks).map(t=>({question:string(t.question),answer:string(t.answer)})).filter(t=>t.question&&t.answer);
  const ex=r.example&&typeof r.example==='object'?r.example as Record<string,unknown>:{};
  if(!string(r.goal)||!string(r.opening)||terms.length<2||steps.length<3||checks.length<2||!string(ex.reasoning)||!string(ex.answer))throw new Error('讲解不完整，请重新编写；需要术语、至少三个步骤、完整例题和两道理解检查。');
  return {goal:string(r.goal),opening:string(r.opening),terms,steps,checks,example:{question:string(ex.question),reasoning:string(ex.reasoning),answer:string(ex.answer)},references:records(r.references).map(t=>({title:string(t.title),url:string(t.url)})).filter(t=>/^https:\/\//.test(t.url))};
}
