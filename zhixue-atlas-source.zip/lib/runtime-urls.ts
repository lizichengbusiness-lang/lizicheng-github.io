// The Pages build replaces these identifiers; the original Site leaves them undefined.
declare const __STUDY_BASE_PATH__: string | undefined;
declare const __STUDY_STATIC__: boolean | undefined;

/** Resolve bundled public assets under either / or a GitHub repository subpath. */
export function assetUrl(path: string): string {
  if (/^(?:https?:\/\/|data:|blob:)/i.test(path)) return path;
  const configured = typeof __STUDY_BASE_PATH__ === 'string' ? __STUDY_BASE_PATH__ : '/';
  const base = configured.replace(/^\/+|\/+$/g, '');
  return `${base ? `/${base}` : ''}/${path.replace(/^\/+/, '')}`;
}

function backendOrigin(value: string): string {
  const error = () => new Error('后端服务地址必须为HTTPS源地址，不包含路径、账号密码、查询或片段；本地调试可使用http://localhost或http://127.0.0.1。');
  const input = value.trim();
  if (!/^https?:\/\/[^/?#@]+\/?$/i.test(input) || /[\s?#\\]/.test(input)) throw error();
  let url: URL;
  try { url = new URL(input); } catch { throw error(); }
  const localHttp = url.protocol === 'http:' && (url.hostname === 'localhost' || url.hostname === '127.0.0.1');
  if ((url.protocol !== 'https:' && !localHttp) || url.username || url.password || url.pathname !== '/' || url.search || url.hash) throw error();
  return url.origin;
}

/** API endpoints stay at /api on the backend, independently of the frontend base path. */
export function apiUrl(path: string, backendUrl?: string): string {
  const endpoint = `/${path.replace(/^\/+/, '')}`;
  if (!/^\/api(?:\/|$)/.test(endpoint) || /[\\\r\n]/.test(endpoint) || endpoint.split('/').some(segment => segment === '.' || segment === '..')) throw new Error('API路径必须以/api开头，且不能包含路径跳转。');
  if (backendUrl?.trim()) return `${backendOrigin(backendUrl)}${endpoint}`;
  if (typeof __STUDY_STATIC__ !== 'undefined' && __STUDY_STATIC__) throw new Error('GitHub Pages需要先配置后端服务地址');
  return endpoint;
}
