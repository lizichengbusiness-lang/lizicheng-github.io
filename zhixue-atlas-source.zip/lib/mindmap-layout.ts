import type {Topic} from './learning-data';
import {beginnerLesson} from './beginner-lessons';

export type MapFocus={kind:'book'}|{kind:'chapter';id:string}|{kind:'topic';id:string};
export type MapNode={id:string;kind:'book'|'chapter'|'topic'|'concept';title:string;subtitle:string;tone:number;x:number;y:number;width:number;height:number;target?:MapFocus;topicId?:string;meaning?:string;central?:boolean};
export type MapEdge={from:string;to:string;kind:'branch'|'before'|'after'|'concept';tone:number};
export type MapLayout={nodes:MapNode[];edges:MapEdge[];focusTitle:string;description:string};
export function sameFocus(a:MapFocus,b:MapFocus){return a.kind===b.kind&&(a.kind==='book'||(b.kind!=='book'&&a.id===b.id));}
export function makeMindmap(topics:Topic[],focus:MapFocus,bookTitle:string,fromContents:boolean):MapLayout{
 const groups=[...new Set(topics.map(t=>t.group))],nodes:MapNode[]=[],edges:MapEdge[]=[];
 const tone=(group:string)=>Math.max(0,groups.indexOf(group))%4;
 const place=(node:Omit<MapNode,'x'|'y'>,cx:number,cy:number)=>{nodes.push({...node,x:cx-node.width/2,y:cy-node.height/2});return node.id;};
 const chapter=(group:string,cx:number,cy:number,central=false)=>place({id:`chapter:${group}`,kind:'chapter',title:group,subtitle:`${topics.filter(t=>t.group===group).length} 个知识点`,tone:tone(group),width:central?286:258,height:central?132:108,target:{kind:'chapter',id:group},central},cx,cy);
 const topic=(t:Topic,cx:number,cy:number,subtitle:string,central=false)=>place({id:`topic:${t.id}`,kind:'topic',title:t.title,subtitle,tone:tone(t.group),width:central?286:248,height:central?142:82,target:{kind:'topic',id:t.id},topicId:t.id,central},cx,cy);
 const link=(from:string,to:string,kind:MapEdge['kind'],color:number)=>edges.push({from,to,kind,tone:color});
 if(focus.kind==='book'||(focus.kind==='chapter'&&!groups.includes(focus.id))||(focus.kind==='topic'&&!topics.some(t=>t.id===focus.id))){
  const perSide=Math.ceil(groups.length/2),height=Math.max(460,perSide*155),cy=height/2;
  const root=place({id:'book',kind:'book',title:bookTitle,subtitle:`${groups.length} ${fromContents?'章 / 组':'学习模块'} · ${topics.length} 个知识点`,tone:0,width:270,height:124,target:{kind:'book'},central:true},530,cy);
  groups.forEach((group,i)=>{const side=i%2===0?-1:1,column=groups.filter((_,j)=>j%2===i%2),row=Math.floor(i/2),y=cy+(row-(column.length-1)/2)*155;const id=chapter(group,530+side*360,y);link(root,id,'branch',tone(group));});
  return{nodes,edges,focusTitle:'全书思维导图',description:fromContents?'点击章节展开知识点，再点击知识点聚焦学习关系。':'示例学习模块，非教材原目录。点击分支逐层展开。'};
 }
 if(focus.kind==='chapter'){
  const children=topics.filter(t=>t.group===focus.id),rows=Math.ceil(children.length/2),height=Math.max(420,rows*112),cy=height/2,root=chapter(focus.id,530,cy,true);
  children.forEach((t,i)=>{const side=i%2===0?-1:1,column=children.filter((_,j)=>j%2===i%2),row=Math.floor(i/2),y=cy+(row-(column.length-1)/2)*112;const id=topic(t,530+side*365,y,'本章知识点');link(root,id,'branch',tone(t.group));});
  return{nodes,edges,focusTitle:focus.id,description:`已聚焦${fromContents?'章节':'模块'}，仅显示它与包含的 ${children.length} 个知识点。点击任一知识点继续放大。`};
 }
 const current=topics.find(t=>t.id===focus.id)!;
 const before=topics.filter(t=>t.id!==current.id&&current.prerequisites.includes(t.id));
 const after=topics.filter(t=>t.id!==current.id&&t.prerequisites.includes(current.id)&&!before.some(b=>b.id===t.id));
 const lesson=current.lesson||(current.sourceType==='课程主题示例'?beginnerLesson(current.id):undefined),terms=lesson?.terms||[];
 const rows=Math.max(before.length,after.length,1),bodyHeight=Math.max(160,rows*96),cy=130+bodyHeight/2;
 const root=topic(current,530,cy,'当前知识点',true),parent=place({id:`chapter:${current.group}`,kind:'chapter',title:current.group,subtitle:'所属章节 · 点击展开',tone:tone(current.group),width:224,height:78,target:{kind:'chapter',id:current.group}},530,50);
 link(parent,root,'branch',tone(current.group));
 before.forEach((t,i)=>{const id=topic(t,165,cy+(i-(before.length-1)/2)*96,'前置 · 建议先学');link(id,root,'before',tone(t.group));});
 after.forEach((t,i)=>{const id=topic(t,895,cy+(i-(after.length-1)/2)*96,'后续 · 接着学习');link(root,id,'after',tone(t.group));});
 terms.forEach((t,i)=>{const columns=Math.min(4,terms.length),row=Math.floor(i/columns),rowCount=Math.min(columns,terms.length-row*columns),x=530+(i%columns-(rowCount-1)/2)*253,y=cy+bodyHeight/2+93+row*104;
  const id=place({id:`concept:${i}`,kind:'concept',title:t.name,subtitle:'本节概念 · 点击释义',tone:tone(current.group),width:224,height:76,meaning:t.meaning},x,y);link(root,id,'concept',tone(current.group));
 });
 return{nodes,edges,focusTitle:current.title,description:`已聚焦知识点，仅显示所属章节、${before.length} 个前置、${after.length} 个后续知识点${terms.length?`和 ${terms.length} 个本节概念`:''}。`};
}
export function mapBounds(nodes:MapNode[]){
 if(!nodes.length)return{x:0,y:0,width:1000,height:500};
 const left=Math.min(...nodes.map(n=>n.x))-50,top=Math.min(...nodes.map(n=>n.y))-50;
 return{x:left,y:top,width:Math.max(...nodes.map(n=>n.x+n.width))+50-left,height:Math.max(...nodes.map(n=>n.y+n.height))+50-top};
}
export function edgeCurve(a:MapNode,b:MapNode,vertical=false){
 const ax=a.x+a.width/2,ay=a.y+a.height/2,bx=b.x+b.width/2,by=b.y+b.height/2;
 if(vertical||Math.abs(bx-ax)<150){const start=ay<by?a.y+a.height:a.y,end=ay<by?b.y:b.y+b.height,mid=(start+end)/2;return`M ${ax} ${start} C ${ax} ${mid}, ${bx} ${mid}, ${bx} ${end}`;}
 const start=ax<bx?a.x+a.width:a.x,end=ax<bx?b.x:b.x+b.width,mid=(start+end)/2;
 return`M ${start} ${ay} C ${mid} ${ay}, ${mid} ${by}, ${end} ${by}`;
}
