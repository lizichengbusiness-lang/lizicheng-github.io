import { inferField, type StudyField } from './subject-catalog';

export type ReadingSource = { title: string; url: string; text: string };
export type ReadingContext = { subject?: string; field?: StudyField };
const biologicalReadings = {
  glycolysis: { title: 'OpenStax Biology 2e · Glycolysis', url: 'https://openstax.org/books/biology-2e/pages/7-2-glycolysis' },
  enzyme: { title: 'OpenStax Biology 2e · Enzymes', url: 'https://openstax.org/books/biology-2e/pages/6-5-enzymes' },
  atp: { title: 'OpenStax Biology 2e · ATP', url: 'https://openstax.org/books/biology-2e/pages/6-4-atp-adenosine-triphosphate' },
};

function referenceFor(topic: string, context?: ReadingContext): { title: string; url: string } | undefined {
  const subject = context?.subject?.trim() || '';
  const field = context?.field || (subject ? inferField(subject) : undefined);
  // Legacy biochemistry requests did not include a field. Require a clear title,
  // never a generic id such as "enzyme", before using the old biology mapping.
  const explicitBiologyTitle = /糖酵解|酶与催化|酶的催化|ATP与能量偶联|\bglycolysis\b/i.test(topic);
  const biology = field === 'life-science' || (!field && explicitBiologyTitle);
  if (biology) {
    if (/糖酵解|\bglycolysis\b/i.test(topic)) return biologicalReadings.glycolysis;
    if (/酶与催化|酶的催化|酶催化|\benzymes?\b/i.test(topic)) return biologicalReadings.enzyme;
    if (/\bATP\b|能量偶联/i.test(topic)) return biologicalReadings.atp;
  }
  if (field === 'computing' && /python/i.test(`${subject} ${topic}`)) {
    if (/变量|赋值|类型|数据|字符串|数字|第一个|入门|程序/i.test(topic)) return { title: 'Python 官方教程 · Python 速览', url: 'https://docs.python.org/zh-cn/3/tutorial/introduction.html' };
    if (/循环|条件|迭代|函数|参数|控制/i.test(topic)) return { title: 'Python 官方教程 · 控制流工具', url: 'https://docs.python.org/zh-cn/3/tutorial/controlflow.html' };
  }
  if (field === 'math' && /函数|极限|微积分|calculus/i.test(`${subject} ${topic}`)) {
    if (/极限|limit/i.test(topic)) return { title: 'OpenStax Calculus Volume 1 · The Limit of a Function', url: 'https://openstax.org/books/calculus-volume-1/pages/2-2-the-limit-of-a-function' };
    if (/函数|function/i.test(topic) && !/求导|导数|积分|复变|广义|泛函/i.test(topic)) return { title: 'OpenStax Calculus Volume 1 · Review of Functions', url: 'https://openstax.org/books/calculus-volume-1/pages/1-1-review-of-functions' };
  }
  if (field === 'humanities' && /历史|history/i.test(subject) && /史料|证据|文献|材料/i.test(topic)) return { title: '美国国家档案馆 · Document Analysis', url: 'https://www.archives.gov/education/lessons/worksheets' };
  return undefined;
}

export async function publicReading(topic: string, _id: string, context?: ReadingContext): Promise<ReadingSource[]> {
  const selected = referenceFor(topic, context);
  if (selected) {
    try {
      const r = await fetch(selected.url, { signal: AbortSignal.timeout(10000) });
      if (r.ok) {
        const html = (await r.text()).slice(0, 400000);
        const text = html.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]*>/g, ' ').replace(/&[^; ]+;/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 16000);
        if (text.length > 300) return [{ ...selected, text }];
      }
    } catch { /* Fall back to a query with the subject included. */ }
  }
  try {
    const cleanTopic = topic.replace(/^第[\d一二三四五六七八九十]+[章节]\s*|^\d+(\.\d+)*\s*/, '').trim();
    const q = [context?.subject?.trim(), cleanTopic].filter(Boolean).join(' ').replace(/[\u0000-\u001f]/g, ' ').slice(0, 220);
    if (!q) return [];
    const url = new URL('https://zh.wikipedia.org/w/api.php');
    for (const [key, value] of Object.entries({ action: 'query', generator: 'search', gsrsearch: q, gsrlimit: '2', prop: 'extracts|info', explaintext: '1', exchars: '4500', inprop: 'url', format: 'json', formatversion: '2' })) url.searchParams.set(key, value);
    const r = await fetch(url, { headers: { 'User-Agent': 'ZhixueLearning/1.0 (educational reading references)' }, signal: AbortSignal.timeout(10000) });
    if (!r.ok) return [];
    const data = await r.json() as { query?: { pages?: { title?: unknown; fullurl?: unknown; extract?: unknown }[] } };
    return (Array.isArray(data.query?.pages) ? data.query.pages : []).filter((p): p is { title: string; fullurl: string; extract: string } => typeof p.title === 'string' && typeof p.extract === 'string' && p.extract.length > 100 && typeof p.fullurl === 'string' && /^https:\/\/zh\.wikipedia\.org\//.test(p.fullurl)).map(p => ({ title: `维基百科 · ${p.title}（辅助核对）`, url: p.fullurl, text: p.extract.slice(0, 4500) }));
  } catch {
    return [];
  }
}
