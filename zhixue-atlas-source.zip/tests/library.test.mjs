import assert from 'node:assert/strict';
import { createDefaultLibrary, createSpace, mergeLibraries, parseLibrary, serializeLibrary, updateLibrarySpace } from '../lib/library-store.ts';
import { initialCourses, sampleTopics } from '../lib/learning-data.ts';
import { beginnerLesson } from '../lib/beginner-lessons.ts';

const original = createDefaultLibrary();
assert.equal(original.schemaVersion, 3);
assert.equal(original.activeId, 'sample-biochemistry');
assert.equal(original.spaces[0].selected, 'glycolysis');
assert.deepEqual(JSON.parse(JSON.stringify(original.spaces[0].topics)), sampleTopics);
assert.deepEqual(original.spaces[0].courses, initialCourses);

const legacy = {
  schemaVersion: 2, title: '动物生物化学', kind: '示例主题框架', selected: 'amino',
  topics: [{ ...sampleTopics[0], lesson: beginnerLesson('amino') }], courses: initialCourses,
  learned: ['amino'], saved: ['amino'], notes: { amino: '我自己的理解，不能因迁移丢失。' },
  source: { name: '历史资料', text: '原有摘录', importedOn: '2026-10-22T10:00:00Z', apiKey: 'source-secret' },
  bookPlan: { title: '动物生物化学', author: '马海田', edition: '第六版', toc: '第一章 氨基酸', importedOn: '2026-10-22T10:00:00Z', apiKey: 'plan-secret' },
  settings: { apiKey: 'do-not-save', visionKey: 'do-not-save-images' }, apiKey: 'top-secret',
  images: ['data:image/jpeg;base64,do-not-save'], bookDraft: { images: ['discard'] },
};
const migrated = parseLibrary(legacy), first = migrated.spaces[0];
assert.equal(first.mode, 'sample');
assert.equal(first.selected, 'amino');
assert.deepEqual(first.learned, ['amino']);
assert.deepEqual(first.saved, ['amino']);
assert.equal(first.notes.amino, legacy.notes.amino);
assert.equal(first.courses.length, 4);
assert.deepEqual(first.topics[0].lesson, beginnerLesson('amino'));
assert.equal(first.source.text, '原有摘录');
assert.equal(first.bookPlan.toc, '第一章 氨基酸');
const serialized = serializeLibrary(migrated);
assert.doesNotMatch(serialized, /secret|do-not-save|bookDraft|data:image|settings|apiKey|visionKey/);
assert.deepEqual(parseLibrary(serialized), migrated);

const calculus = createSpace({ id: 'math', title: '大学高等数学' });
assert.deepEqual(calculus.topics, []);
assert.deepEqual(calculus.courses, []);
assert.equal(calculus.selected, '');
assert.equal(calculus.level, '零基础');
assert.notEqual(calculus.field, first.field);
const emptyBackup = parseLibrary({ title: '计算机基础', topics: [], courses: [] });
assert.equal(emptyBackup.spaces[0].topics.length, 0);
assert.equal(emptyBackup.spaces[0].courses.length, 0);
const legacyMath = parseLibrary({ title: '大学高等数学', topics: [sampleTopics[0]], learned: ['amino'], notes: { amino: '数学空间笔记' }, courses: [] });
assert.equal(legacyMath.spaces[0].courses.length, 0, 'A migrated non-biochemistry space must not receive the four biochemistry courses');

let combined = mergeLibraries(migrated, { schemaVersion: 3, activeId: calculus.id, spaces: [calculus] });
combined = { ...combined, activeId: calculus.id };
const lateResult = updateLibrarySpace(combined, first.id, (space) => ({ notes: { ...space.notes, amino: '晚到的旧课请求结果' }, learned: ['amino'] }));
assert.equal(lateResult.activeId, calculus.id);
assert.equal(lateResult.spaces.find((space) => space.id === calculus.id).notes.amino, undefined);
assert.equal(lateResult.spaces.find((space) => space.id === first.id).notes.amino, '晚到的旧课请求结果');
assert.equal(combined.spaces.find((space) => space.id === first.id).notes.amino, legacy.notes.amino, 'Updates must be immutable');
assert.equal(updateLibrarySpace(combined, 'missing-id', { title: '错误写入' }), combined);
assert.equal(updateLibrarySpace(combined, first.id, { id: calculus.id }).spaces[0].id, first.id, 'A patch cannot redirect an update to another book');

const collision = mergeLibraries(combined, migrated);
assert.equal(collision.spaces.length, 3);
assert.equal(new Set(collision.spaces.map((space) => space.id)).size, 3);
assert.equal(collision.activeId, calculus.id);
assert.equal(collision.spaces[0].id, first.id);
assert.equal(collision.spaces[0].notes.amino, legacy.notes.amino);
assert.equal(collision.spaces[2].notes.amino, legacy.notes.amino);
assert.notEqual(collision.spaces[2].id, first.id);
assert.equal(parseLibrary({ schemaVersion: 3, activeId: 'missing', spaces: [calculus] }).activeId, calculus.id);

const untrusted = parseLibrary({ title: '计算机基础', topics: [], courses: [
  { ...initialCourses[0], apiKey: 'course-secret', official: 'javascript:alert(1)' },
  { ...initialCourses[0], id: 'duplicate' },
  { ...initialCourses[1], url: 'https://example.com/fake-course' },
  { ...initialCourses[2], url: 'javascript:alert(1)' },
  { ...initialCourses[3], url: 'http://www.youtube.com/playlist?list=PLUl4u3cNGP62wNcIMfinU64CAfreShjpt' },
] });
assert.equal(untrusted.spaces[0].courses.length, 1);
assert.equal(untrusted.spaces[0].courses[0].official, undefined);
assert.doesNotMatch(serializeLibrary(untrusted), /course-secret|apiKey|javascript:/);
const extraSecrets = { ...migrated, apiKey: 'library-secret', spaces: migrated.spaces.map((space) => ({ ...space, visionKey: 'space-secret', topics: space.topics.map((topic) => ({ ...topic, apiKey: 'topic-secret', lesson: { ...topic.lesson, apiKey: 'lesson-secret' } })) })) };
assert.doesNotMatch(serializeLibrary(extraSecrets), /library-secret|space-secret|topic-secret|lesson-secret|apiKey|visionKey/);
const repeatedTopicIds = parseLibrary({ title: '重复标识导入检查', topics: [
  { ...sampleTopics[0], id: 'topic' }, { ...sampleTopics[1], id: 'topic-1' }, { ...sampleTopics[2], id: 'topic' },
  { ...sampleTopics[3], id: '' }, { title: '没有 ID 的主题一', explanation: '原有讲解一' }, { title: '没有 ID 的主题二', explanation: '原有讲解二' },
] }).spaces[0];
assert.equal(new Set(repeatedTopicIds.topics.map((topic) => topic.id)).size, 6, 'Generated suffixes must not collide with another imported topic id');
assert.ok(repeatedTopicIds.topics.every((topic) => topic.id));
const damagedOptionalLesson = parseLibrary({ ...legacy, topics: [{ ...sampleTopics[0], lesson: { goal: '不完整讲解' } }] }).spaces[0];
assert.equal(damagedOptionalLesson.topics[0].explanation, sampleTopics[0].explanation);
assert.equal(damagedOptionalLesson.topics[0].lesson, undefined);
assert.equal(damagedOptionalLesson.notes.amino, legacy.notes.amino);
const fieldMetadata = createSpace({ title: '自定义教材', field: 'math', level: '已有基础', bookPlan: { title: '自定义教材', author: '作者', edition: '第一版', toc: '第一章', importedOn: '2026-10-22T10:00:00Z', field: 'math', level: '已有基础' } });
const fieldRoundtrip = parseLibrary(serializeLibrary({ schemaVersion: 3, activeId: fieldMetadata.id, spaces: [fieldMetadata] })).spaces[0];
assert.equal(fieldRoundtrip.field, 'math');
assert.equal(fieldRoundtrip.level, '已有基础');
assert.equal(fieldRoundtrip.bookPlan.field, 'math');
assert.equal(fieldRoundtrip.bookPlan.level, '已有基础');
assert.throws(() => parseLibrary({ ...migrated, schemaVersion: 4 }), /更新版本/);
assert.throws(() => parseLibrary({ schemaVersion: 3, spaces: [] }));
assert.throws(() => parseLibrary({ apiKey: 'not-a-library' }));
console.log(JSON.stringify({ legacyMigration: 'passed', independentBooks: 'passed', lateAsyncIsolation: 'passed', importCollisions: 'passed', secretsRemoved: 'passed', emptySubject: 'passed', courseUrlValidation: 'passed' }));
