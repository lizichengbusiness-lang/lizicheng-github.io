import assert from 'node:assert/strict';
import {parseContents,topicsFromContents,validateLesson} from '../lib/curriculum.ts';
import {beginnerLesson} from '../lib/beginner-lessons.ts';
import {validateTopics} from '../lib/learning-utils.ts';
import {sampleTopics} from '../lib/learning-data.ts';
import {POST} from '../app/api/model/route.ts';
const toc='目录\n第一章 生物分子……1\n1.1 氨基酸 3\n第一节 蛋白质……12\n第二章 酶\n2.1 酶的性质 28';
const chapters=parseContents(toc);assert.equal(chapters.length,2);assert.deepEqual(chapters[0].sections,['1.1 氨基酸','第一节 蛋白质']);assert.equal(topicsFromContents(chapters).length,3);
assert.deepEqual(parseContents(''),[]);assert.equal(topicsFromContents(parseContents('第一章 只有章名'))[0].title,'第一章 只有章名');
for(const t of sampleTopics){const lesson=beginnerLesson(t.id);assert.ok(lesson,`Missing lesson ${t.id}`);validateLesson(lesson);assert.ok(JSON.stringify(lesson).length>650,`Too short: ${t.id}`);}
const custom={...topicsFromContents(chapters)[0],lesson:beginnerLesson('amino')};assert.deepEqual(validateTopics([custom])[0].lesson,custom.lesson);assert.equal(validateTopics([custom])[0].chapterId,custom.chapterId);assert.throws(()=>validateLesson({goal:'只有标题'}));
const originalFetch=globalThis.fetch,calls=[];
globalThis.fetch=async(url,options)=>{
 calls.push({url:String(url),options});
 if(String(url).startsWith('https://openstax.org/'))return new Response('<main>'+('ATP and glucose metabolism. '.repeat(40))+'</main>');
 if(String(url)==='https://api.deepseek.com/chat/completions'||String(url)==='https://api.openai.com/v1/chat/completions')return Response.json({choices:[{finish_reason:'stop',message:{content:JSON.stringify({lesson:beginnerLesson('glycolysis'),prerequisites:[]})}}]});
 throw new Error('Unexpected network access');
};
const req=(b)=>new Request('http://local/api/model',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
const base={provider:'deepseek',model:'test-model',apiKey:'test-only-secret',task:'lesson',text:JSON.stringify({title:'糖酵解',id:'glycolysis'})};
assert.equal((await POST(req({...base,provider:'unknown'}))).status,400);assert.equal(calls.length,0);
assert.equal((await POST(req({...base,provider:'openai',task:'bookvision',images:['https://example.com/remote-image.jpg']}))).status,400);assert.equal(calls.length,0);
const good=await POST(req(base));assert.equal(good.status,200);const result=await good.json();assert.equal(result.references.length,1);assert.match(result.researchStatus,/已读取/);
const payload=JSON.parse(calls.at(-1).options.body);assert.match(payload.messages[0].content,/学生第一次接触/);assert.match(payload.messages[0].content,/没有书籍正文/);assert.equal(calls.at(-1).options.headers.Authorization,'Bearer test-only-secret');assert.ok(!JSON.stringify(result).includes('test-only-secret'));
const vision=await POST(req({...base,provider:'openai',task:'bookvision',text:'仅目录图片',images:['data:image/jpeg;base64,YQ==']}));assert.equal(vision.status,200);assert.equal(JSON.parse(calls.at(-1).options.body).messages[1].content[1].type,'image_url');
globalThis.fetch=originalFetch;
console.log(JSON.stringify({beginnerLessons:sampleTopics.length,tocHierarchy:'passed',backupRoundtrip:'passed',invalidLesson:'rejected',visionPayload:'passed (mock)',lessonProvider:'passed (mock)',liveModel:'not tested — no credentials'}));
