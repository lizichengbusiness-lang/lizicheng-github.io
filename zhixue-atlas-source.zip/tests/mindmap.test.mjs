import assert from 'node:assert/strict';
import {makeMindmap,mapBounds,edgeCurve} from '../lib/mindmap-layout.ts';
import {sampleTopics} from '../lib/learning-data.ts';
const book=makeMindmap(sampleTopics,{kind:'book'},'动物生物化学',false);
assert.equal(book.nodes.filter(n=>n.kind==='chapter').length,4);
assert.equal(book.nodes.filter(n=>n.kind==='book').length,1);
const group='生物分子',chapter=makeMindmap(sampleTopics,{kind:'chapter',id:group},'动物生物化学',false);
assert.deepEqual(new Set(chapter.nodes.filter(n=>n.kind==='topic').map(n=>n.topicId)),new Set(sampleTopics.filter(t=>t.group===group).map(t=>t.id)));
assert.ok(!chapter.nodes.some(n=>n.topicId==='glycolysis'),'Chapter focus must hide unrelated topics');
const focus=makeMindmap(sampleTopics,{kind:'topic',id:'glycolysis'},'动物生物化学',false),current=sampleTopics.find(t=>t.id==='glycolysis');
const expected=new Set([current.id,...current.prerequisites,...sampleTopics.filter(t=>t.prerequisites.includes(current.id)).map(t=>t.id)]);
assert.deepEqual(new Set(focus.nodes.filter(n=>n.kind==='topic').map(n=>n.topicId)),expected);
assert.ok(focus.nodes.filter(n=>n.kind==='concept').length>=2);
for(const t of sampleTopics){const graph=makeMindmap(sampleTopics,{kind:'topic',id:t.id},'测试',false),ids=new Set(graph.nodes.map(n=>n.id));assert.equal(ids.size,graph.nodes.length);for(const e of graph.edges){assert.ok(ids.has(e.from)&&ids.has(e.to));const a=graph.nodes.find(n=>n.id===e.from),b=graph.nodes.find(n=>n.id===e.to);assert.ok(!/NaN|Infinity/.test(edgeCurve(a,b,e.kind==='concept')));}for(const n of graph.nodes)for(const m of graph.nodes){if(n===m)continue;assert.ok(n.x+n.width<=m.x||m.x+m.width<=n.x||n.y+n.height<=m.y||m.y+m.height<=n.y,`Node overlap: ${t.id} ${n.id} ${m.id}`);}assert.ok(mapBounds(graph.nodes).height>0);}
assert.equal(makeMindmap(sampleTopics,{kind:'topic',id:'missing'},'测试',false).nodes[0].kind,'book');
const imported=[{...sampleTopics[0],id:'import-1',group:'第一章',prerequisites:[],sourceType:'目录已校对 · 讲解待编写'}];
assert.equal(makeMindmap(imported,{kind:'topic',id:'import-1'},'导入书籍',true).nodes.filter(n=>n.kind==='topic').length,1);
console.log(JSON.stringify({chapterFocus:'only own topics',topicFocus:'only direct neighbors',allTopicLayouts:'no overlaps',edges:'valid',importedContents:'no invented dependencies'}));
