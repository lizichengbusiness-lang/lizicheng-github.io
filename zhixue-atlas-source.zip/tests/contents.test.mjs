import assert from 'node:assert/strict';
import {parseContents,topicsFromContents} from '../lib/curriculum.ts';

const chinese=parseContents('目录\n第一章 生物分子……1\n1.1 氨基酸 3\n第一节 蛋白质……12\n第二章 酶\n2.1 酶的性质 28');
assert.equal(chinese.length,2);
assert.deepEqual(chinese[0].sections,['1.1 氨基酸','第一节 蛋白质']);
assert.equal(topicsFromContents(chinese).length,3);

const english=parseContents('Table of Contents\nChapter One: Functions . . . . 1\n1.1 Functions and Models 3\n1.2 A Catalog of Essential Functions……10\nChapter Two: Limits and Derivatives……43\n2.1 The Tangent and Velocity Problems 45');
assert.deepEqual(english.map(c=>c.title),['Chapter One: Functions','Chapter Two: Limits and Derivatives']);
assert.deepEqual(english[0].sections,['1.1 Functions and Models','1.2 A Catalog of Essential Functions']);
assert.equal(topicsFromContents(english).length,3);

const units=parseContents('Unit I: Numbers ... 1\n1.1 Counting ... 2\nUnit IV: Algebra ... 27\n4.1 Equations ... 28\nUnit Twenty-One: Probability ... 64\n21.1 Events ... 65');
assert.deepEqual(units.map(c=>c.title),['Unit I: Numbers','Unit IV: Algebra','Unit Twenty-One: Probability']);
assert.deepEqual(units.map(c=>c.sections.length),[1,1,1]);

const parts=parseContents('第一篇 导论……1\n第一节 研究对象……3\n第二部 历史……19\n第二节 时间与证据……20\nPart III: Sources ... viii\nPrimary sources ... 11');
assert.deepEqual(parts.map(c=>c.title),['第一篇 导论','第二部 历史','Part III: Sources']);
assert.deepEqual(parts[1].sections,['第二节 时间与证据']);

const numbered=parseContents('Contents\n1 Introduction to Programming .... 1\n1.1 Programs and Computers .... 2\n1.1.1 A first program .... 3\n2. Data Types .... 9\n2.1 Numbers .... 10\n3、Control Flow .... 22');
assert.deepEqual(numbered.map(c=>c.title),['1 Introduction to Programming','2. Data Types','3、Control Flow']);
assert.deepEqual(numbered[0].sections,['1.1 Programs and Computers','1.1.1 A first program']);
assert.equal(topicsFromContents(numbered).length,4);
assert.equal(topicsFromContents(numbered).at(-1).title,'3、Control Flow');

const subsections=parseContents('第一章 历史研究\n第一节 证据\n1、文献材料\n第二节 方法\n第二章 社会变迁\n第一节 工业社会');
assert.equal(subsections.length,2,'Section headings and numbered lists stay inside an explicit chapter');
assert.deepEqual(subsections[0].sections,['第一节 证据','1、文献材料','第二节 方法']);

const sparse=parseContents('Chapter 3: Matrices\n3.2 Matrix Products\nChapter 7: Eigenvalues');
assert.deepEqual(sparse.map(c=>c.title),['Chapter 3: Matrices','Chapter 7: Eigenvalues']);
assert.equal(topicsFromContents(sparse).length,2,'Only the provided sections and sectionless chapters become units');
assert.equal(topicsFromContents(sparse).at(-1).title,'Chapter 7: Eigenvalues');
assert.equal(parseContents('Chapter 1')[0].title,'Chapter 1','A bare chapter number is not removed as a page number');
assert.deepEqual(parseContents('1 入门．．．．１\n1 . 1 第一课 . . .\n2 应用 ９').map(c=>({title:c.title,sections:c.sections})),[{title:'1 入门',sections:['1 . 1 第一课']},{title:'2 应用',sections:[]}]);
assert.deepEqual(parseContents(' \n\n目录\n'),[]);
assert.deepEqual(parseContents(''),[]);
assert.deepEqual(topicsFromContents([]),[]);

console.log(JSON.stringify({contentsFormats:['Chinese chapter/part','English spelled number','Roman numeral','integer chapter','decimal section'],pageNumbers:'removed',sectionHierarchy:'preserved',sparseContents:'no invented chapters',emptyContents:'passed'}));
