import assert from 'node:assert/strict';
import { fieldOptions, inferField, subjectPresets, findPreset } from '../lib/subject-catalog.ts';
import { validateLesson } from '../lib/curriculum.ts';
import { publicReading } from '../lib/public-reading.ts';
import { POST } from '../app/api/model/route.ts';

assert.equal(fieldOptions.length, 5);
for (const [title, field] of [['动物生物化学', 'life-science'], ['高等数学', 'math'], ['Python 入门', 'computing'], ['历史学习方法', 'humanities'], ['自定义技能', 'general']]) assert.equal(inferField(title), field);
assert.equal(findPreset('高数')?.field, 'math');
assert.equal(findPreset('Python 3')?.id, 'python-intro');
assert.equal(findPreset('历史')?.id, 'history-methods');
assert.equal(findPreset(''), undefined);
assert.equal(findPreset('某本未收录的高数教材第三版'), undefined, 'Do not pretend a generic preset matches a specific textbook edition');

const allIds = new Set();
assert.equal(subjectPresets.length, 3);
for (const preset of subjectPresets) {
  assert.ok(preset.topics.length >= 6 && preset.topics.length <= 10);
  assert.ok(!/生化|生物/.test(preset.title));
  const ids = new Set(preset.topics.map(t => t.id));
  assert.equal(ids.size, preset.topics.length);
  const visited = new Set();
  for (const [i, topic] of preset.topics.entries()) {
    assert.ok(!allIds.has(topic.id), 'Topic ids must not collide between presets');
    allIds.add(topic.id);
    for (const id of topic.prerequisites) { assert.ok(ids.has(id)); assert.ok(visited.has(id), 'Prerequisites must come before the topic'); }
    visited.add(topic.id);
    if (i < 2) {
      const lesson = validateLesson(topic.lesson);
      assert.ok(lesson.example.question && lesson.example.reasoning && lesson.example.answer);
      assert.ok(lesson.steps.every(s => s.body.length >= 70), `Expected teaching paragraphs in ${topic.id}`);
      assert.ok(JSON.stringify(lesson).length > 1100, `Expected substantial original lesson in ${topic.id}`);
      assert.ok(lesson.references.length >= 1);
      assert.ok(lesson.references.every(r => new URL(r.url).protocol === 'https:'));
    } else {
      assert.equal(topic.lesson, undefined);
      assert.match(topic.sourceType, /待编写/);
      assert.match(topic.explanation, /待编写/);
    }
  }
}

const originalFetch = globalThis.fetch;
const calls = [];
let wikiFails = false;
globalThis.fetch = async (url, options) => {
  calls.push({ url: String(url), options });
  if (String(url).startsWith('https://zh.wikipedia.org/w/api.php')) {
    if (wikiFails) return new Response('Unavailable', { status: 503 });
    return Response.json({ query: { pages: [{ title: '辅助材料', fullurl: 'https://zh.wikipedia.org/wiki/Test', extract: '供核对的内容。'.repeat(40) }, { title: '不可信跳转', fullurl: 'https://evil.example/source', extract: 'x'.repeat(200) }] } });
  }
  if (String(url).startsWith('https://openstax.org/') || String(url).startsWith('https://docs.python.org/') || String(url).startsWith('https://www.archives.gov/')) return new Response('<main>' + 'Reference information for the requested learning topic. '.repeat(40) + '</main>');
  if (String(url) === 'https://api.deepseek.com/chat/completions') return Response.json({ choices: [{ finish_reason: 'stop', message: { content: JSON.stringify({ lesson: subjectPresets[0].topics[0].lesson, prerequisites: [] }) } }] });
  throw new Error(`Unexpected fetch: ${url}`);
};

try {
  const beforeBiology = calls.length;
  const biology = await publicReading('糖酵解', 'glycolysis');
  assert.equal(biology.length, 1, 'Old explicit biochemistry requests must keep working');
  assert.match(calls[beforeBiology].url, /biology-2e/);

  let start = calls.length;
  const isolated = await publicReading('糖酵解', 'enzyme', { subject: 'Python 入门', field: 'computing' });
  assert.equal(isolated.length, 1);
  assert.ok(calls.slice(start).every(c => !c.url.includes('biology-2e')), 'Other fields may not inherit biology sources from ids or topic names');
  const query = new URL(calls[start].url).searchParams.get('gsrsearch');
  assert.match(query, /Python 入门/); assert.match(query, /糖酵解/);

  start = calls.length;
  await publicReading('自定义章节', 'atp', { subject: '高等数学', field: 'math' });
  assert.ok(calls.slice(start).every(c => !c.url.includes('biology-2e')));
  assert.match(new URL(calls[start].url).searchParams.get('gsrsearch'), /高等数学 自定义章节/);

  start = calls.length;
  const math = await publicReading('极限的直观意义', 'enzyme', { subject: '高等数学', field: 'math' });
  assert.match(math[0].url, /calculus-volume-1/);
  assert.ok(calls.slice(start).every(c => !c.url.includes('biology-2e')));

  start = calls.length;
  const computing = await publicReading('变量、赋值与类型', 'glycolysis', { subject: 'Python 入门', field: 'computing' });
  assert.match(computing[0].url, /docs\.python\.org/);
  assert.ok(calls.slice(start).every(c => !c.url.includes('biology-2e')));

  wikiFails = true;
  assert.deepEqual(await publicReading('未知主题', 'enzyme', { subject: '未知科目', field: 'general' }), [], 'Search failure must not invent a source');
  wikiFails = false;

  const req = body => new Request('http://local/api/model', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const base = { provider: 'deepseek', model: 'test-model', apiKey: 'only-for-mocked-tests' };
  const callsBeforeInvalid = calls.length;
  assert.equal((await POST(req(null))).status, 400);
  assert.equal((await POST(new Request('http://local/api/model', { method: 'POST', body: '{broken' }))).status, 400);
  assert.equal((await POST(req({ ...base, task: 'lesson', text: 'null' }))).status, 400);
  assert.equal((await POST(req({ ...base, task: 'lesson', text: '[]' }))).status, 400);
  assert.equal(calls.length, callsBeforeInvalid, 'Invalid input must never reach reading or model providers');
  for (const [field, subject, title, expected] of [
    ['math', '高等数学', '极限', /公式推导/],
    ['computing', 'Python 入门', '变量', /逐行追踪/],
    ['humanities', '历史学习方法', '史料', /语境.*证据来源/],
    ['general', '自定义科目', '自定义主题', /不强套生物化学/],
  ]) {
    const response = await POST(req({ ...base, task: 'lesson', text: JSON.stringify({ title, id: 'enzyme', field, subject, level: '零基础', chapters: [{ title: '第一章' }] }) }));
    assert.equal(response.status, 200);
    const payload = JSON.parse(calls.at(-1).options.body);
    assert.match(payload.messages[0].content, expected);
    const context = JSON.parse(payload.messages[1].content);
    assert.equal(context.subject, subject); assert.equal(context.field, field); assert.equal(context.level, '零基础');
    assert.equal(context.material.chapters[0].title, '第一章');
    assert.ok(!(await response.text()).includes(base.apiKey));
  }

  for (const text of ['高等数学', JSON.stringify({ subject: 'Python 入门', field: 'computing', level: '零基础' })]) {
    const response = await POST(req({ ...base, task: 'outline', text }));
    assert.equal(response.status, 200);
    const payload = JSON.parse(calls.at(-1).options.body);
    const context = JSON.parse(payload.messages[1].content);
    assert.ok(context.subject);
    assert.match(payload.messages[0].content, /建议框架/);
    assert.match(payload.messages[0].content, /不能形成循环/);
  }
  assert.equal((await POST(req({ ...base, task: 'outline', text: '{"field":"math"}' }))).status, 400);
} finally {
  globalThis.fetch = originalFetch;
}

console.log(JSON.stringify({ subjectPresets: subjectPresets.length, readyLessons: 6, prerequisiteOrder: 'passed', contextualReferences: 'passed', crossSubjectSourceIsolation: 'passed', subjectTeachingStyles: 'passed (mock)', outlineCompatibility: 'passed (mock)', missingReferences: 'no invented sources', liveModel: 'not tested — no credentials' }));
