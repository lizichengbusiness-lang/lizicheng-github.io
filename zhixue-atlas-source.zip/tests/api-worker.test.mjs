import assert from 'node:assert/strict';
import actualWorker, { createApiWorker } from '../github/api-worker.ts';

const website = 'https://learner.github.io';
const environment = { ALLOWED_ORIGINS: `${website}, https://second.example, http://localhost:4173, http://127.0.0.1:4173, http://[::1]:4173` };
const calls = [];
const worker = createApiWorker({
  model: async request => {
    calls.push({ path: new URL(request.url).pathname, method: request.method, body: await request.json() });
    return Response.json({ text: '入门讲解' }, { headers: { 'Cache-Control': 'public, max-age=3600', Vary: 'Accept-Encoding', 'Access-Control-Allow-Origin': '*' } });
  },
  courses: async request => {
    calls.push({ path: new URL(request.url).pathname, method: request.method, body: await request.json() });
    return Response.json({ courses: [{ title: '原站课程', url: 'https://www.youtube.com/playlist?list=PL12345678' }] }, { status: 201 });
  },
});
const request = (path, { origin = website, method = 'POST', body, headers = {} } = {}) => new Request(`https://api.example${path}`, {
  method, headers: { ...(origin !== null ? { Origin: origin } : {}), ...headers }, ...(body === undefined ? {} : { body: JSON.stringify(body) }),
});
function noCache(response) { assert.equal(response.headers.get('Cache-Control'), 'no-store'); assert.ok(response.headers.get('Vary').split(/,\s*/).some(v => v.toLowerCase() === 'origin')); }

for (const origin of ['https://learner.github.io.evil.example', 'http://learner.github.io', 'https://evil.example', 'null', null]) {
  const denied = await worker.fetch(request('/api/model', { origin, body: { apiKey: 'do-not-forward' } }), environment);
  assert.equal(denied.status, 403); assert.equal(denied.headers.get('Access-Control-Allow-Origin'), null); noCache(denied);
}
assert.equal(calls.length, 0, 'An invalid or missing origin must not reach a handler');
for (const configuration of ['', '*', 'https://*.github.io', `${website}/repo`, `${website}/`, 'http://remote.example']) {
  const denied = await worker.fetch(request('/api/courses'), { ALLOWED_ORIGINS: configuration });
  assert.equal(denied.status, 403, `Invalid configuration ${configuration} must fail closed`);
}
assert.equal(calls.length, 0);

const preflight = await worker.fetch(request('/api/model', { method: 'OPTIONS', headers: { 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'content-type' } }), environment);
assert.equal(preflight.status, 204); assert.equal(await preflight.text(), ''); assert.equal(calls.length, 0);
assert.equal(preflight.headers.get('Access-Control-Allow-Origin'), website);
assert.equal(preflight.headers.get('Access-Control-Allow-Headers'), 'Content-Type'); noCache(preflight);
assert.equal((await worker.fetch(request('/api/model', { method: 'OPTIONS', headers: { 'Access-Control-Request-Method': 'DELETE' } }), environment)).status, 405);
assert.equal((await worker.fetch(request('/api/model', { method: 'OPTIONS', headers: { 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'x-extra' } }), environment)).status, 403);
assert.equal((await worker.fetch(request('/api/model', { method: 'OPTIONS', origin: 'https://evil.example', headers: { 'Access-Control-Request-Method': 'POST' } }), environment)).status, 403);
assert.equal(calls.length, 0);

const health = await worker.fetch(request('/health', { method: 'GET', origin: null }), {});
assert.equal(health.status, 200); assert.equal((await health.json()).ok, true); noCache(health);
const healthyCors = await worker.fetch(request('/health', { method: 'GET' }), environment);
assert.equal(healthyCors.headers.get('Access-Control-Allow-Origin'), website);
const unknown = await worker.fetch(request('/api/unknown'), environment);
assert.equal(unknown.status, 404); noCache(unknown);
const wrongMethod = await worker.fetch(request('/api/model', { method: 'GET' }), environment);
assert.equal(wrongMethod.status, 405); assert.equal(wrongMethod.headers.get('Allow'), 'POST, OPTIONS');
assert.equal(calls.length, 0);

const modelPayload = { task: 'lesson', text: '{"subject":"高等数学"}', apiKey: 'transient-key' };
const model = await worker.fetch(request('/api/model', { body: modelPayload }), environment);
assert.equal(model.status, 200); assert.deepEqual(calls[0], { path: '/api/model', method: 'POST', body: modelPayload });
assert.equal(model.headers.get('Access-Control-Allow-Origin'), website); assert.equal(model.headers.get('Access-Control-Allow-Credentials'), null);
assert.match(model.headers.get('Vary'), /Accept-Encoding/); noCache(model); assert.equal((await model.json()).text, '入门讲解');
const courses = await worker.fetch(request('/api/courses', { body: { query: '高等数学' } }), environment);
assert.equal(courses.status, 201); assert.equal(calls[1].path, '/api/courses'); assert.equal((await courses.json()).courses.length, 1); noCache(courses);
for (const origin of ['https://second.example', 'http://localhost:4173', 'http://127.0.0.1:4173', 'http://[::1]:4173']) {
  const response = await worker.fetch(request('/api/model', { origin, body: {} }), environment);
  assert.equal(response.status, 200); assert.equal(response.headers.get('Access-Control-Allow-Origin'), origin);
}

const failing = createApiWorker({ model: () => { throw new Error('secret-provider-key'); } });
const failed = await failing.fetch(request('/api/model'), environment);
assert.equal(failed.status, 502); assert.ok(!(await failed.text()).includes('secret-provider-key')); noCache(failed);

// Verify the default worker delegates to the real route: invalid credentials are
// rejected by its existing validation without making any upstream request.
const originalFetch = globalThis.fetch;
globalThis.fetch = async () => { throw new Error('No network should be used for invalid input'); };
try {
  const real = await actualWorker.fetch(request('/api/model', { body: { provider: 'unknown', apiKey: 'never-echo-this', model: 'x', task: 'lesson', text: '{}' } }), environment);
  assert.equal(real.status, 400); assert.equal(real.headers.get('Access-Control-Allow-Origin'), website);
  assert.ok(!(await real.text()).includes('never-echo-this')); noCache(real);
  const invalidCourse = await actualWorker.fetch(request('/api/courses', { body: { query: '' } }), environment);
  assert.equal(invalidCourse.status, 400); noCache(invalidCourse);
} finally { globalThis.fetch = originalFetch; }

console.log(JSON.stringify({ exactOriginAllowlist: 'passed', failClosed: 'passed', preflight: 'passed', routes: 'passed', defaultRoutes: 'passed', noStoreAndVary: 'passed', errorsDoNotExposeSecrets: 'passed', remoteDeployment: 'not performed' }));
