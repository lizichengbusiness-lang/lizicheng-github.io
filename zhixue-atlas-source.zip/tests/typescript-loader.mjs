import {registerHooks} from 'node:module';
import fs from 'node:fs';
import {fileURLToPath,pathToFileURL} from 'node:url';
import path from 'node:path';
const root=path.resolve('.');
registerHooks({resolve(specifier,context,next){
 if(specifier.startsWith('@/'))specifier=pathToFileURL(path.join(root,specifier.slice(2))).href;
 if((specifier.startsWith('./')||specifier.startsWith('../')||specifier.startsWith('file:'))&&!path.extname(specifier)){
  const url=new URL(specifier,context.parentURL);if(fs.existsSync(fileURLToPath(url)+'.ts'))return next(url.href+'.ts',context);
 }
 return next(specifier,context);
}});
