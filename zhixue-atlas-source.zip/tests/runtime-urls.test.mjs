import assert from 'node:assert/strict';
import {assetUrl,apiUrl} from '../lib/runtime-urls.ts';

const baseDescriptor=Object.getOwnPropertyDescriptor(globalThis,'__STUDY_BASE_PATH__');
const staticDescriptor=Object.getOwnPropertyDescriptor(globalThis,'__STUDY_STATIC__');
try {
  delete globalThis.__STUDY_BASE_PATH__;
  delete globalThis.__STUDY_STATIC__;
  assert.equal(assetUrl('/images/book.webp'),'/images/book.webp');
  assert.equal(assetUrl('images/book.webp'),'/images/book.webp');
  assert.equal(apiUrl('/api/model'),'/api/model','The existing Site keeps its same-origin API');
  assert.equal(apiUrl('api/courses'),'/api/courses');
  assert.equal(apiUrl('/api/model','  '),'/api/model');
  assert.equal(apiUrl('/api/model','https://backend.example/'),'https://backend.example/api/model');
  assert.equal(apiUrl('/api/courses','https://backend.example:8443'),'https://backend.example:8443/api/courses');
  assert.equal(apiUrl('/api/model','http://localhost:8787/'),'http://localhost:8787/api/model');
  assert.equal(apiUrl('/api/courses','http://127.0.0.1:8787'),'http://127.0.0.1:8787/api/courses');

  const invalidOrigins=[
    'https://user:password@backend.example','https://user@backend.example','https://@backend.example',
    'https://backend.example?key=secret','https://backend.example/?','https://backend.example#fragment','https://backend.example/#',
    'https://backend.example/api','https://backend.example/api/','https://backend.example/./','https://backend.example/api/../',
    'https://backend.example//','https://backend.example\\api','https://backend. example','https://backend.\nexample',
    'http://backend.example','http://127.0.0.2','http://localhost.example','http://[::1]',
    'ftp://backend.example','javascript:alert(1)','//backend.example','backend.example','http:localhost',
  ];
  for(const origin of invalidOrigins)assert.throws(()=>apiUrl('/api/model',origin),/HTTPS源地址/,origin);
  assert.throws(()=>apiUrl('https://unrelated.example/model'),/API路径/);
  assert.throws(()=>apiUrl('/api/../model'),/API路径/);
  assert.throws(()=>apiUrl('/api/\\unrelated.example'),/API路径/);

  // Node's global bindings simulate the compile-time identifiers replaced by Vite.
  globalThis.__STUDY_BASE_PATH__='/learning-atlas/';
  globalThis.__STUDY_STATIC__=true;
  assert.equal(assetUrl('/images/book.webp'),'/learning-atlas/images/book.webp');
  assert.equal(assetUrl('images/book.webp'),'/learning-atlas/images/book.webp');
  assert.equal(assetUrl(''),'/learning-atlas/');
  assert.equal(assetUrl('https://images.example/book.webp'),'https://images.example/book.webp');
  assert.equal(assetUrl('data:image/png;base64,YQ=='),'data:image/png;base64,YQ==');
  assert.throws(()=>apiUrl('/api/model'),{message:'GitHub Pages需要先配置后端服务地址'});
  assert.throws(()=>apiUrl('/api/courses',' '),{message:'GitHub Pages需要先配置后端服务地址'});
  assert.equal(apiUrl('/api/model','https://worker.example'),'https://worker.example/api/model','The repository base path must not replace or prefix /api');
  assert.equal(apiUrl('/api/courses','http://localhost:8787'),'http://localhost:8787/api/courses');
  assert.throws(()=>apiUrl('/api/model','https://worker.example/api'),/HTTPS源地址/);

  globalThis.__STUDY_BASE_PATH__='learning-atlas';
  assert.equal(assetUrl('/images/book.webp'),'/learning-atlas/images/book.webp');
  globalThis.__STUDY_BASE_PATH__='/';
  globalThis.__STUDY_STATIC__=false;
  assert.equal(assetUrl('/images/book.webp'),'/images/book.webp');
  assert.equal(apiUrl('/api/model'),'/api/model');
} finally {
  if(baseDescriptor)Object.defineProperty(globalThis,'__STUDY_BASE_PATH__',baseDescriptor);else delete globalThis.__STUDY_BASE_PATH__;
  if(staticDescriptor)Object.defineProperty(globalThis,'__STUDY_STATIC__',staticDescriptor);else delete globalThis.__STUDY_STATIC__;
}
console.log(JSON.stringify({sameOriginSite:'preserved',pagesAssets:'repository subpath supported',pagesApi:'explicit backend required',apiPrefix:'preserved',backendOrigins:'validated',localDebug:'localhost and 127.0.0.1',globalSimulation:'passed'}));
