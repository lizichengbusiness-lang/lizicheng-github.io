import assert from 'node:assert/strict';
import {reviseContents} from '../lib/contents-update.ts';
import {parseContents,topicsFromContents,validateLesson} from '../lib/curriculum.ts';
import {createDefaultLibrary,createSpace} from '../lib/library-store.ts';
import {beginnerLesson} from '../lib/beginner-lessons.ts';

const plan=(title,toc='')=>({title,author:'作者',edition:'第三版',toc,field:'life-science',level:'零基础',importedOn:'2026-10-23T12:00:00Z'});
const freeze=value=>{if(value&&typeof value==='object'){Object.freeze(value);for(const item of Object.values(value))freeze(item);}return value;};

// Saving the sample's editable directory must keep all 24 existing, readable lessons.
const original=createDefaultLibrary().spaces[0];
const sample={...original,learned:['amino','glycolysis'],saved:['protein'],notes:{amino:'我的氨基酸笔记',glycolysis:'沿碳骨架理解'},selected:'glycolysis'};
const groups=[...new Set(sample.topics.map(t=>t.group))];
const toc=groups.map((group,i)=>`第${i+1}章 ${group}\n${sample.topics.filter(t=>t.group===group).map((t,j)=>`${i+1}.${j+1} ${t.title}`).join('\n')}`).join('\n');
freeze(sample);
const sampleItems=topicsFromContents(parseContents(toc));
freeze(sampleItems);
const samplePatch=reviseContents(sample,plan(sample.title,toc),sampleItems);
assert.equal(samplePatch.topics.length,24);
for(const old of sample.topics){
  const updated=samplePatch.topics.find(t=>t.title.endsWith(old.title));
  assert.ok(updated,old.title);
  assert.equal(updated.explanation,old.explanation);
  assert.deepEqual(updated.lesson,beginnerLesson(old.id),`Sample lesson must survive the id change: ${old.id}`);
  validateLesson(updated.lesson);
  assert.ok(updated.prerequisites.every(id=>samplePatch.topics.some(t=>t.id===id)));
  assert.equal(updated.prerequisites.length,old.prerequisites.length);
}
const remappedAmino=samplePatch.topics.find(t=>t.title.endsWith('氨基酸与肽键')).id;
const remappedGlycolysis=samplePatch.topics.find(t=>t.title.endsWith('糖酵解')).id;
assert.deepEqual(samplePatch.learned,[remappedAmino,remappedGlycolysis]);
assert.equal(samplePatch.notes[remappedAmino],'我的氨基酸笔记');
assert.equal(samplePatch.notes[remappedGlycolysis],'沿碳骨架理解');
assert.equal(samplePatch.selected,remappedGlycolysis);
assert.equal(samplePatch.saved.length,1);
assert.equal(samplePatch.saved[0],samplePatch.topics.find(t=>t.title.endsWith('蛋白质的结构与功能')).id);
assert.ok(!Object.hasOwn(samplePatch,'courses'),'Course resources are not modified by revising the directory');
assert.equal(({...sample,...samplePatch}).courses,sample.courses);
assert.equal(samplePatch.mode,'book');

const topic=(id,title,group,extra={})=>({id,title,group,brief:'已编写简介',explanation:`${id} 的原有讲解`,points:[],misconception:'',prerequisites:[],tags:[],sourceType:'已编写课程',...extra});
const lesson=beginnerLesson('amino');
const moving=createSpace({id:'moving',title:'学习项目',mode:'subject',topics:[
  topic('function','1.1 函数','Chapter One: 基础',{lesson}),
  topic('limit','1.2 极限','Chapter One: 基础',{prerequisites:['function','removed']}),
  topic('removed','1.3 将删除的节','Chapter One: 基础'),
],learned:['function','limit'],saved:['limit'],notes:{function:'旧章里的函数笔记',limit:'极限笔记',removed:'已删除节笔记'},selected:'limit'});
const movingNew=[topic('new-limit','2.2 极限','第二章 变化'),topic('new-function','4.1 函数','第四章 应用')];
freeze(moving);freeze(movingNew);
const moved=reviseContents(moving,plan('学习项目'),movingNew);
assert.equal(moved.topics[1].explanation,'function 的原有讲解');
assert.deepEqual(moved.topics[1].lesson,lesson);
assert.equal(moved.notes['new-function'],'旧章里的函数笔记');
assert.equal(moved.notes['new-limit'],'极限笔记');
assert.deepEqual(moved.learned,['new-function','new-limit']);
assert.deepEqual(moved.saved,['new-limit']);
assert.equal(moved.selected,'new-limit');
assert.deepEqual(moved.topics[0].prerequisites,['new-function'],'Only surviving existing relationships are remapped');
assert.equal(moved.mode,'subject');

// Matching a duplicate in one chapter must not make the other duplicate safe to cross-match.
const repeated=createSpace({title:'重复题名',topics:[topic('a','1.1 基础','第一章 A'),topic('b','2.1 基础','第二章 B')],
  notes:{a:'A章笔记',b:'B章笔记'},learned:['a','b'],saved:['b'],selected:'b'});
const repeatedNew=[topic('a-new','1.1 基础','第一章 A'),topic('c-new','3.1 基础','第三章 C')];
const ambiguous=reviseContents(repeated,plan('重复题名'),repeatedNew);
assert.equal(ambiguous.notes['a-new'],'A章笔记');
assert.equal(ambiguous.notes['c-new'],undefined);
assert.deepEqual(ambiguous.learned,['a-new']);
assert.deepEqual(ambiguous.saved,[]);
assert.equal(ambiguous.topics[0].explanation,'a 的原有讲解');
assert.equal(ambiguous.topics[1],repeatedNew[1],'An unmatched item keeps its new contents');
assert.equal(ambiguous.selected,'a-new');
const reordered=reviseContents(repeated,plan('重复题名'),[topic('b-new','4.1 基础','第四章 B'),topic('a-new','6.1 基础','第六章 A')]);
assert.equal(reordered.notes['a-new'],'A章笔记');
assert.equal(reordered.notes['b-new'],'B章笔记');
assert.equal(reordered.selected,'b-new');
const englishRepeated=createSpace({title:'English chapters',topics:[topic('a','Basics','Chapter One: A'),topic('b','Basics','Chapter Two: B')],notes:{a:'A notes',b:'B notes'}});
const englishRenumbered=reviseContents(englishRepeated,plan('English chapters'),[topic('new-b','Basics','Part IX: B'),topic('new-a','Basics','Unit Twenty-One: A')]);
assert.deepEqual(englishRenumbered.notes,{'new-a':'A notes','new-b':'B notes'});

const oneOld=createSpace({title:'One-to-one',topics:[topic('only','主题','章A')],learned:['only'],notes:{only:'只可保留一次'}});
const noReuse=reviseContents(oneOld,plan('One-to-one'),[topic('same-chapter','主题','章A'),topic('other-chapter','主题','章B')]);
assert.deepEqual(noReuse.learned,['same-chapter']);
assert.deepEqual(noReuse.notes,{'same-chapter':'只可保留一次'});
assert.equal(noReuse.topics[1].explanation,'other-chapter 的原有讲解');

// Even exact title+chapter pairs must be unique, rather than assigned by list order.
const duplicatedPair=createSpace({title:'重复同章',topics:[topic('dup-a','概念','共同章'),topic('dup-b','概念','共同章')],notes:{'dup-a':'不能猜配的笔记'}});
const noGuess=reviseContents(duplicatedPair,plan('重复同章'),[topic('new-dup','概念','共同章')]);
assert.deepEqual(noGuess.notes,{});
assert.equal(noGuess.topics[0].explanation,'new-dup 的原有讲解');

const changed=reviseContents(moving,plan('学习项目'),[topic('renamed','新题名','Chapter One: 基础')]);
assert.deepEqual(changed.notes,{});
assert.deepEqual(changed.learned,[]);
assert.equal(changed.topics[0].lesson,undefined);
assert.equal(changed.selected,'renamed');
assert.equal(reviseContents(moving,plan('空目录'),[]).selected,'');

console.log(JSON.stringify({sampleLessons:'24 readable after directory revision',uniqueTitleMoves:'preserved',duplicates:'chapter identity required',oneToOne:'no reuse',selectionAndProgress:'mapped',relationships:'existing only',courses:'unchanged',inputMutation:'none'}));
